<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->
 
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Schedules | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
  
    <!-- CALENDAR External CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.css">
  
  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh; /* Make sidebar height fixed */
    width: 78px;
    background: #155843;
    padding: 6px 14px;
    z-index: 1;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
}

.sidebar.open .logo-details,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
}

.sidebar .logo-details #btn {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    font-size: 22px;
    text-align: center;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    margin-top: 20px;
    height: 100%;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li.profile {
    position: fixed;
    height: 60px;
    width: 78px;
    left: 0;
    bottom: -8px;
    padding: 10px 14px;
    background: #1d1b31;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open li.profile {
    width: 250px;
}

.sidebar li .profile-details {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.profile .name,
.sidebar li.profile .job {
    font-size: 15px;
    font-weight: 400;
    color: #fff;
    white-space: nowrap;
}

.sidebar li.profile .job {
    font-size: 12px;
}

.sidebar li.profile #log_out {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    background: #1d1b31;
    width: 100%;
    height: 60px;
    line-height: 60px;
    transition: all 0.5s ease;
}


.sidebar.open .profile #log_out {
    width: 30px;
    background: none;
}

.sidebar li.active a {
    background: #fff !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */
    .sidebar li .profile .name {
        font-size: calc(1.5vw + 10px); /* Adjust profile name font size */
    }

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */
    .sidebar li.profile #log_out {
        width: auto; /* Allow the button to only take up space for the icon */
        background-color: transparent; /* Match sidebar background */
        border-top: none; /* Remove top border */
        padding: 10px; /* Add padding for consistent spacing */
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align the logout icon to the left */
    }

    .sidebar li.profile #log_out i.bx.box-log-out {
        font-size: calc(2vw + 1px); /* Keep icon size consistent */
        color: #fff; /* Match icon color with other sidebar items */
        margin-right: 10px; /* Add some space between the icon and any text */
    }

    /* Profile section width adjustment */
    .sidebar li.profile {
        width: 9.2vh; /* padding to sa logout button para pantay lang sa navbar */
    }

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }

    /* Hide the "Cue Time" and "By Group:" text */
    .sidebar .profile .name,
    .sidebar .profile .job {
        display: none !important; /* Ensure these elements are hidden */
    }

    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }/* NAV BAR SA GILID END */


}

  </style>

</head>

<body>
<!-- Sidebar Section -->
    <div class="sidebar">
        <div class="logo-details">
            <div class="logo_name">Cue Time 🎱</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list">

            <!-- Walk-In Reservation-->
            <li>
                <a href="landingpage.php">
                    <i class='bx bx-user'></i>
                    <span class="links_name">Walk-In</span>
                </a>
            </li> 


            <!-- Analytics Link -->
            <li>
                <a href="landingpage1.php">
                    <i class='bx bxs-bookmark-alt-plus'></i>
                    <span class="links_name">Reservation</span>
                </a>
            </li>

            <!-- Files Link -->
            <li class="active"><!--Active tab indicator-->
                <a href="landingpage2.php">
                    <i class='bx bx-calendar'></i>
                    <span class="links_name">Schedules</span>
                </a>
            </li>

            <!-- Revenue Link -->
            <li>
                <a href="landingpage3.php">
                    <i class='bx bxs-bar-chart-square'></i>
                    <span class="links_name">Analytics</span>
                </a>
            </li>

            
            <!-- Company Section -->
            <li class="profile">
                <div class="profile-details">
                    <img src="assets/Images/1ball.png" alt="profileImg">
                    <div class="name_job">
                        <div class="name">Cue Time</div>
                        <div class="job">By Group: 6</div>
                    </div>
                </div>
                <div id="log_out-container">
                     <i class='bx bx-log-out' id="log_out"></i>
                </div>
            </li>
        </ul>
    </div>
<!-- Sidebar Section -->

<!-- MAIN CONTENT -->
  <div class="ui container" style="background-color: white;">
    <div class="ui grid">
      <div class="ui sixteen column">
        <div id="calendar"></div>
      </div>
    </div>
  </div>

<!-- MAIN CONTENT -->

 <!-- External JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>

    <script>
document.addEventListener("DOMContentLoaded", function() {
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");

    // Toggle sidebar visibility on button click
    closeBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
    });

    // Logout Confirmation Script
    document.getElementById('log_out').addEventListener('click', function (e) {
        e.preventDefault(); // Prevent default link action
        Swal.fire({
            title: 'Are you sure?',
            text: 'You will be logged out.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, log me out!',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'logout.php'; // Redirect to logout page
            }
            // Do nothing on cancel, avoiding layout recalculation
        });
    });

    // SCRIPT NG CALENDAR
    $('#calendar').fullCalendar({
    header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,basicWeek,basicDay'
    },
    defaultDate: new Date().toISOString().split('T')[0], // Set default date to today
    navLinks: true, // Can click day/week names to navigate views
    editable: false,  // Disable event moving
    eventLimit: true, // Allow "more" link when too many events
    events: function(start, end, timezone, callback) {
        $.ajax({
            url: 'get_events.php',
            dataType: 'json',
            success: function(data) {
                console.log(data);
                var events = data.map(function(event) {
                    var startDate = moment(event.start, "YYYY-MM-DD hh:mm A").format("YYYY-MM-DDTHH:mm:ss");
                    var endDate = moment(event.end, "YYYY-MM-DD hh:mm A").format("YYYY-MM-DDTHH:mm:ss");

                    return {
                        title: event.title,
                        start: startDate,
                        end: endDate,
                        description: event.description
                    };
                });
                callback(events);
            },
            error: function(xhr, status, error) {
                console.error("Error fetching events:", status, error);
            }
        });
    }
});

});

</script>

</body>

</html>