<?php
// Include your database connection
require_once 'conn.php'; // Ensure this points to your database connection file

// Set timezone to the desired timezone
date_default_timezone_set('Asia/Manila'); // Set to Philippines timezone

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Helper function for error messages
    function respondWithError($message) {
        echo json_encode(['status' => 'error', 'message' => $message]);
        exit;
    }

    // Sanitize inputs
    $firstName = htmlspecialchars(trim($_POST['first_name']));
    $lastName = htmlspecialchars(trim($_POST['last_name']));
    $phoneNumber = htmlspecialchars(trim($_POST['phone_number']));
    $tableNo = (int) $_POST['table'];
    $hours = (int) $_POST['hours']; // Ensure hours is an integer
    $paymentMethod = htmlspecialchars(trim($_POST['payment_method']));

    // Validate inputs
    if (empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($tableNo) || empty($hours) || empty($paymentMethod)) {
        respondWithError('All fields are required!');
    }

    if (!preg_match('/^09\d{9}$/', $phoneNumber)) {
        respondWithError('Invalid phone number format.');
    }

    if ($hours <= 0) {
        respondWithError('Hours must be greater than 0.');
    }

    // Calculate start and end time
    $startTime = new DateTime(); // Current time
    $endTime = clone $startTime;
    $endTime->add(new DateInterval("PT{$hours}H")); // Add hours

    $startTimeFormatted = $startTime->format("Y-m-d H:i:s");
    $endTimeFormatted = $endTime->format("Y-m-d H:i:s");

    // Registration date
    $registrationDateFormatted = (new DateTime())->format("Y-m-d H:i:s");

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'cue_time');
    if ($conn->connect_error) {
        respondWithError('Database connection failed: ' . $conn->connect_error);
    }

    // Check for overlapping reservations
    $query = "SELECT * FROM customers WHERE table_no = ? AND (
        (start_time < ? AND end_time > ?) OR
        (start_time < ? AND end_time > ?)
    )";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $tableNo, $endTimeFormatted, $startTimeFormatted, $startTimeFormatted, $endTimeFormatted);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        respondWithError('Table is already in use.');
    }
    $result->close();

    // Set entry_type as 'walk-in' for the submission
    $entryType = 'walk-in';  // Automatically set to 'walk-in'

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO customers (first_name, last_name, phone_number, table_no, hours, payment_method, registration_date, start_time, end_time, entry_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssissssss", $firstName, $lastName, $phoneNumber, $tableNo, $hours, $paymentMethod, $registrationDateFormatted, $startTimeFormatted, $endTimeFormatted, $entryType);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Registration submitted successfully.']);
    } else {
        respondWithError('Failed to submit registration.');
    }

    $stmt->close();
    $conn->close();
}
?>
