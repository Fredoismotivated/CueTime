<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Walk-in | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  
  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    width: 100vw;
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

.sidebar {
    height: 100vh; /* Make sidebar height fixed */
    width: 78px;
    background: #155843;
    padding: 6px 14px;
    z-index: 1;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
}

.sidebar.open .logo-details,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
}

.sidebar .logo-details #btn {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    font-size: 22px;
    text-align: center;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    margin-top: 20px;
    height: 100%;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li.profile {
    position: fixed;
    height: 60px;
    width: 78px;
    left: 0;
    bottom: -8px;
    padding: 10px 14px;
    background: #1d1b31;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open li.profile {
    width: 250px;
}

.sidebar li .profile-details {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.profile .name,
.sidebar li.profile .job {
    font-size: 15px;
    font-weight: 400;
    color: #fff;
    white-space: nowrap;
}

.sidebar li.profile .job {
    font-size: 12px;
}

.sidebar li.profile #log_out {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    background: #1d1b31;
    width: 100%;
    height: 60px;
    line-height: 60px;
    transition: all 0.5s ease;
}


.sidebar.open .profile #log_out {
    width: 30px;
    background: none;
}

.sidebar li.active a {
    background: #fff !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */
    .sidebar li .profile .name {
        font-size: calc(1.5vw + 10px); /* Adjust profile name font size */
    }

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */
    .sidebar li.profile #log_out {
        width: auto; /* Allow the button to only take up space for the icon */
        background-color: transparent; /* Match sidebar background */
        border-top: none; /* Remove top border */
        padding: 10px; /* Add padding for consistent spacing */
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align the logout icon to the left */
    }

    .sidebar li.profile #log_out i.bx.box-log-out {
        font-size: calc(2vw + 1px); /* Keep icon size consistent */
        color: #fff; /* Match icon color with other sidebar items */
        margin-right: 10px; /* Add some space between the icon and any text */
    }

    /* Profile section width adjustment */
    .sidebar li.profile {
        width: 9.2vh; /* padding to sa logout button para pantay lang sa navbar */
    }

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }

    /* Hide the "Cue Time" and "By Group:" text */
    .sidebar .profile .name,
    .sidebar .profile .job {
        display: none !important; /* Ensure these elements are hidden */
    }

    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }/* NAV BAR SA GILID END */

}

  </style>

</head>

<body>
<!-- Sidebar Section -->
<?php include('sidebar.php'); ?>
<!-- Sidebar Section -->

<div style="display: flex; flex-grow: 1; justify-content: center; align-items: center; min-height: 100vh; background-color: #f7f7f7;">
        <div style="max-width: 500px; width: 100%; background: #fff; margin: 0; box-shadow: 2px 2px 4px rgba(0,0,0,0.125); padding: 30px;">
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 25px; color: #fec107; text-transform: uppercase; text-align: center;">
                Walk-In Registration
            </div>

            <!-- First Name Field -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">First Name</label>
                <input type="text" id="first_name" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
            </div>

            <!-- Last Name Field -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Last Name</label>
                <input type="text" id="last_name" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
            </div>

            <!-- Phone Number -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Phone Number</label>
                <input type="text" id="phone_number" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
            </div>

            <!-- Table Selection -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Table</label>
                <div style="position: relative; width: 100%; height: 37px;">
                    <select id="table" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
                        <option value="">Select</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                    </select>
                </div>
            </div>

            <!-- Hours Selection -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Hours</label>
                <div style="position: relative; width: 100%; height: 37px;">
                    <select id="hours" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
                        <option value="">Select</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
            </div>

            <!-- Payment Method Selection -->
            <div style="margin-bottom: 15px; display: flex; align-items: center;">
                <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Payment Method</label>
                <div style="position: relative; width: 100%; height: 37px;">
                    <select id="payment_method" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
                        <option value="">Select</option>
                        <option value="Cash">Cash</option>
                        <option value="G-Cash">G-Cash</option>
                    </select>
                </div>
            </div>

            <!-- Submit Button -->
            <div style="margin-bottom: 0;">
                <input type="submit" value="Register"
                       style="width: 100%; padding: 8px 10px; font-size: 15px; border: 0px; background: #fec107; color: #fff; cursor: pointer; border-radius: 3px; outline: none;"
                       onmouseover="this.style.backgroundColor='#ffb300';" 
                       onmouseout="this.style.backgroundColor='#fec107';"
                       onclick="validateForm(event)">
            </div>
        </div>
    </div>


    <script>
function validateForm(event) {
    event.preventDefault(); // Prevent form submission

    var firstName = document.getElementById("first_name").value;
    var lastName = document.getElementById("last_name").value;
    var phoneNumber = document.getElementById("phone_number").value;
    var table = document.getElementById("table").value;
    var hours = document.getElementById("hours").value;
    var paymentMethod = document.getElementById("payment_method").value;

    if (firstName === "" || lastName === "" || phoneNumber === "" || table === "" || hours === "" || paymentMethod === "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Please fill out all fields before submitting!',
        });
        return;
    }

    if (!/^\b09\d{9}\b/.test(phoneNumber)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid Phone Number',
            text: 'Please enter a valid phone number (11 digits, starting with 09)!',
        });
        return;
    }

    fetch('submit_registration.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            first_name: firstName,
            last_name: lastName,
            phone_number: phoneNumber,
            table: table,
            hours: hours,
            payment_method: paymentMethod,
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'error') {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message,
                });
            } else {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: data.message,
                }).then(() => {
                    clearForm(); // Clear form on success
                });
            }
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An unexpected error occurred.',
            });
        });
}

// Function to clear form fields
function clearForm() {
    document.getElementById("first_name").value = "";
    document.getElementById("last_name").value = "";
    document.getElementById("phone_number").value = "";
    document.getElementById("table").value = "";
    document.getElementById("hours").value = "";
    document.getElementById("payment_method").value = "";
}

    </script>
<!-- MAIN CONTENT -->

<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>

</body>

</html>