<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>AccountCenter | Cue Time</title>
  <link rel="icon" href="assets/Images/Logo.png" type="image/png" sizes="16x16">
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
</head>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;900&display=swap');

input {
  caret-color: red;
}

body {
  margin: 0;
  min-height: 100vh; /* Use min-height instead of height */
  background: #ecf0f3;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: 'Jost', sans-serif;
}

html {
  overflow-y: scroll; /* Always show scrollbar */
}

.container {
  position: relative;
  width: 480px;
  height: 580px;
  border-radius: 20px;
  padding: 40px;
  box-sizing: border-box;
  background: #ecf0f3;
  box-shadow: 14px 14px 20px #cbced1, -14px -14px 20px white;
}


.brand-logo {
  height: 100px;
  width: 100px;
  background: url("assets/Images/1ball.png") no-repeat center center;
  background-size: contain; /* Ensures the image fits within the circle */
  margin: 0 auto; /* Horizontal centering */
  display: block; /* Ensures the image behaves like a block-level element */
  border-radius: 50%;
  box-sizing: border-box;
  box-shadow: 7px 7px 10px #cbced1, -7px -7px 10px white;
}


.brand-title {
  margin-top: 10px;
  font-weight: 900;
  font-size: 1.8rem;
  color: #838280;
  letter-spacing: 1px;
}

.inputs {
  text-align: left;
  margin-top: 30px;
}

label, input, button {
  display: block;
  width: 100%;
  padding: 0;
  border: none;
  outline: none;
  box-sizing: border-box;
}

label {
  margin-bottom: 4px;
}

label:nth-of-type(2) {
  margin-top: 12px;
}

input::placeholder {
  color: gray;
}

input {
  background: #ecf0f3;
  padding: 10px;
  padding-left: 20px;
  height: 50px;
  font-size: 14px;
  border-radius: 5px;
  border: 2px solid #838280;
}

button {
  color: white;
  margin-top: 12px;
  background: #E3AF12;
  height: 40px;
  border-radius: 20px;
  cursor: pointer;
  font-weight: 900;
  box-shadow: 6px 6px 6px #cbced1, -6px -6px 6px white;
  transition: 0.5s;
}

button:hover {
  box-shadow: none;
  background:rgb(206, 159, 17);
}


h1 {
  position: absolute;
  top: 0;
  left: 0;
}

/* Styling for the terms container */
.terms-container {
  margin-top: 10px;
  text-align: left;
  display: inline-flex; /* Align checkbox and label horizontally */
  align-items: center;  /* Vertically align the checkbox and label */
}

/* Styling for the checkbox */
.terms-container input[type="checkbox"] {
  width: 20px; /* Set width */
  height: 20px; /* Set height */
  margin-right: 10px; /* Space between the checkbox and label */
  position: relative;
  cursor: pointer;
}

/* Styling for the label and link */
.terms-container label {
  font-size: 14px;
  color: #838280;
}

.terms-container a {
  color: #E3AF12;
  text-decoration: none;
}

.terms-container a:hover {
  text-decoration: underline;
}

/* Style for the "Back" button link */
#back-button {
  position: absolute;
  top: 20px; /* Adjust the distance from the top */
  left: 40px; /* Adjust the distance from the left */
  color: white;
  background:rgb(206, 204, 200);
  padding: 10px 15px;
  text-decoration: none;
  border-radius: 5px;
  transition: background 0.3s, color 0.3s;
  font-weight: 900;
}

#back-button i {
  font-size: 1.3em; /* Adjust the icon size here */
}

#back-button:hover {
  background:rgb(82, 81, 79);
}

 /* Para sa password visibility */
 .password-container {
    position: relative;
  }

  .toggle-visibility {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    width: 20px;
    height: 20px;
  }
</style>

<body>
<div class="container">
  <a href="index.php" id="back-button"><i class="bx bx-chevron-left"></i></a>
  <div class="brand-logo"></div>
  <div class="brand-title">Cue Time™</div>
  <div class="inputs">
    <form action="update_password.php" method="POST" id="password-form">
      <label>Your Username</label>
      <input type="text" name="username" placeholder="Username" required />
      <label>Password</label>
      <div class="password-container">
        <input type="password" name="password" id="password" placeholder="New Password" required />
        <img class="toggle-visibility" src="assets/Images/hide.png" onclick="togglePasswordVisibility('password')" alt="Show Password" />
      </div>
      <label>Confirm Password</label>
      <div class="password-container">
        <input type="password" name="confirm-password" id="confirm-password" placeholder="Confirm New Password" required />
        <img class="toggle-visibility" src="assets/Images/hide.png" onclick="togglePasswordVisibility('confirm-password')" alt="Show Confirm Password" />
      </div>

      <!-- Terms and conditions checkbox -->
      <div class="terms-container">
        <input type="checkbox" id="terms" name="terms" required />
        <label for="terms">I agree to the <a href="#" title="Please remember your password this time!">Terms and Conditions</a></label>
      </div>

      <button type="submit">Confirm</button>
    </form>
  </div>
</div>

<script>
  function togglePasswordVisibility(id) {
    var passwordField = document.getElementById(id);
    var toggleIcon = passwordField.nextElementSibling;
    var type = passwordField.type === "password" ? "text" : "password";
    passwordField.type = type;
    toggleIcon.src = type === "password" ? "assets/Images/hide.png" : "assets/Images/show.png";
  }

  // Form submission handling with SweetAlert messages
  document.getElementById('password-form').onsubmit = function(event) {
  event.preventDefault();
  const form = event.target;
  const formData = new FormData(form);

  fetch('update_password.php', {
    method: 'POST',
    body: formData
  }).then(response => response.json())
    .then(data => {
      if (data.success) {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: data.success,
        }).then(() => {
          // Clear the text fields after success
          document.getElementById('password').value = '';
          document.getElementById('confirm-password').value = '';
          
          // Redirect to index.php after clearing fields
          window.location.href = "index.php";
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: data.error,
        });
      }
    }).catch((error) => {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: `An error occurred: ${error.message}`,
      });
    });
};

</script>


</body>
</html>