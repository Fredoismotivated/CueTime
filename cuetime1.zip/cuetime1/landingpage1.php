<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Reservation | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh; /* Make sidebar height fixed */
    width: 78px;
    background: #155843;
    padding: 6px 14px;
    z-index: 1;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
}

.sidebar.open .logo-details,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
}

.sidebar .logo-details #btn {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    font-size: 22px;
    text-align: center;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    margin-top: 20px;
    height: 100%;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li.profile {
    position: fixed;
    height: 60px;
    width: 78px;
    left: 0;
    bottom: -8px;
    padding: 10px 14px;
    background: #1d1b31;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open li.profile {
    width: 250px;
}

.sidebar li .profile-details {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.profile .name,
.sidebar li.profile .job {
    font-size: 15px;
    font-weight: 400;
    color: #fff;
    white-space: nowrap;
}

.sidebar li.profile .job {
    font-size: 12px;
}

.sidebar li.profile #log_out {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    background: #1d1b31;
    width: 100%;
    height: 60px;
    line-height: 60px;
    transition: all 0.5s ease;
}


.sidebar.open .profile #log_out {
    width: 30px;
    background: none;
}

.sidebar li.active a {
    background: #fff !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */
    .sidebar li .profile .name {
        font-size: calc(1.5vw + 10px); /* Adjust profile name font size */
    }

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */
    .sidebar li.profile #log_out {
        width: auto; /* Allow the button to only take up space for the icon */
        background-color: transparent; /* Match sidebar background */
        border-top: none; /* Remove top border */
        padding: 10px; /* Add padding for consistent spacing */
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align the logout icon to the left */
    }

    .sidebar li.profile #log_out i.bx.box-log-out {
        font-size: calc(2vw + 1px); /* Keep icon size consistent */
        color: #fff; /* Match icon color with other sidebar items */
        margin-right: 10px; /* Add some space between the icon and any text */
    }

    /* Profile section width adjustment */
    .sidebar li.profile {
        width: 9.2vh; /* padding to sa logout button para pantay lang sa navbar */
    }

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }

    /* Hide the "Cue Time" and "By Group:" text */
    .sidebar .profile .name,
    .sidebar .profile .job {
        display: none !important; /* Ensure these elements are hidden */
    }

    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }/* NAV BAR SA GILID END */


}

  </style>

</head>

<body>
<!-- Sidebar Section -->
    <div class="sidebar">
        <div class="logo-details">
            <div class="logo_name">Cue Time 🎱</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list">

            <!-- Walk-In Reservation-->
            <li>
                <a href="landingpage.php">
                    <i class='bx bx-user'></i>
                    <span class="links_name">Walk-In</span>
                </a>
            </li> 


            <!-- Analytics Link -->
            <li class="active"><!--Active tab indicator-->
                <a href="landingpage1.php">
                    <i class='bx bxs-bookmark-alt-plus'></i>
                    <span class="links_name">Reservation</span>
                </a>
            </li>

            <!-- Files Link -->
            <li>
                <a href="landingpage2.php">
                    <i class='bx bx-calendar'></i>
                    <span class="links_name">Schedules</span>
                </a>
            </li>

            <!-- Revenue Link -->
            <li>
                <a href="landingpage3.php">
                    <i class='bx bxs-bar-chart-square'></i>
                    <span class="links_name">Analytics</span>
                </a>
            </li>
            
            <!-- Company Section -->
            <li class="profile">
                <div class="profile-details">
                    <img src="assets/Images/1ball.png" alt="profileImg">
                    <div class="name_job">
                        <div class="name">Cue Time</div>
                        <div class="job">By Group: 6</div>
                    </div>
                </div>
                <div id="log_out-container">
                     <i class='bx bx-log-out' id="log_out"></i>
                </div>
            </li>
        </ul>
    </div>
<!-- Sidebar Section -->
 
<!-- MAIN CONTENT -->
<div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f7f7f7;">
  <div style="max-width: 500px; width: 100%; background: #fff; margin: 0; box-shadow: 2px 2px 4px rgba(0,0,0,0.125); padding: 30px;">
    <div style="font-size: 24px; font-weight: 700; margin-bottom: 25px; color: #fec107; text-transform: uppercase; text-align: center;">
      Reservation Form
    </div>

    <div>
      <!-- First Name Field -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">First Name</label>
        <input type="text" id="firstName" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <!-- Last Name Field -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Last Name</label>
        <input type="text" id="lastName" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <!-- Phone Number -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Phone Number</label>
        <input type="text" id="phoneNumber" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <!-- Table Selection -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Table</label>
        <div style="position: relative; width: 100%; height: 37px;">
          <select id="tableSelect" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
            <option value="">Select</option>
            <option value="1">1</option>
            <option value="2">2</option>
          </select>
        </div>
      </div>

      <!-- Reservation Date and Time -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label for="reservation" style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Reservation Date</label>
        <input type="datetime-local" id="reservation" name="reservation" style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <!-- Hours Selection -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Hours</label>
        <div style="position: relative; width: 100%; height: 37px;">
          <select id="hoursSelect" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
            <option value="">Select</option>
            <option value="1">1 hour</option>
            <option value="2">2 hours</option>
            <option value="3">3 hours</option>
            <option value="4">4 hours</option>
            <option value="5">5 hours</option>
          </select>
        </div>
      </div>

      <!-- Payment Method -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Payment Method</label>
        <div style="position: relative; width: 100%; height: 37px;">
          <select id="paymentMethod" style="outline: none; width: 100%; height: 100%; border: 0px; padding: 8px 10px; font-size: 15px; border: 1px solid #d5dbd9; border-radius: 3px; -webkit-appearance: none; -moz-appearance: none; appearance: none;">
            <option value="">Select</option>
            <option value="Cash">Cash</option>
            <option value="G-Cash">G-Cash</option>
          </select>
        </div>
      </div>

      <!-- Submit Button -->
      <div style="margin-bottom: 0;">
        <input type="button" value="Register"
               style="width: 100%; padding: 8px 10px; font-size: 15px; border: 0px; background: #fec107; color: #fff; cursor: pointer; border-radius: 3px; outline: none;"
               onmouseover="this.style.backgroundColor='#ffb300';" 
               onmouseout="this.style.backgroundColor='#fec107';"
               onclick="submitForm();">
      </div>
    </div>
  </div>
</div>

<!-- SweetAlert Function -->
<script>
  function submitForm() {
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const tableSelect = document.getElementById('tableSelect').value.trim();
    const reservationDate = document.getElementById('reservation').value.trim();
    const hoursSelect = document.getElementById('hoursSelect').value.trim();
    const paymentMethod = document.getElementById('paymentMethod').value.trim();

    // Check for empty fields
    if (!firstName || !lastName || !phoneNumber || !tableSelect || !reservationDate || !hoursSelect || !paymentMethod) {
      Swal.fire({
        title: 'Error!',
        text: 'Please fill out all fields before submitting.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    // Validate phone number format (Philippines format starting with 09, 11 digits)
    const phoneRegex = /^\b09\d{9}\b/;
    if (!phoneRegex.test(phoneNumber)) {
      Swal.fire({
        icon: 'error',
        title: 'Invalid Phone Number',
        text: 'Please enter a valid phone number (11 digits, starting with 09).',
      });
      return;
    }

    // Check reservation date is in the future
    const now = new Date();
    const reservationDateTime = new Date(reservationDate);
    if (reservationDateTime <= now) {
      Swal.fire({
        title: 'Invalid Reservation Date',
        text: 'Please select a future date and time for your reservation.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    // Send data to the backend via AJAX
    const data = {
      firstName: firstName,
      lastName: lastName,
      phoneNumber: phoneNumber,
      tableSelect: tableSelect,
      reservationDate: reservationDate,
      hoursSelect: hoursSelect,
      paymentMethod: paymentMethod
    };

    fetch('reservation.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        Swal.fire({
          title: 'Success!',
          text: 'Your reservation has been submitted successfully.',
          icon: 'success',
          confirmButtonText: 'OK'
        });
        // Clear the form fields
        document.getElementById('firstName').value = '';
        document.getElementById('lastName').value = '';
        document.getElementById('phoneNumber').value = '';
        document.getElementById('tableSelect').value = '';
        document.getElementById('reservation').value = '';
        document.getElementById('hoursSelect').value = '';
        document.getElementById('paymentMethod').value = '';
      } else {
        Swal.fire({
          title: 'Error!',
          text: data.message,
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    })
    .catch(error => {
      Swal.fire({
        title: 'Error!',
        text: 'There was an error submitting your reservation.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    });
  }
</script>

<!-- MAIN CONTENT -->


<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>

</body>

</html>