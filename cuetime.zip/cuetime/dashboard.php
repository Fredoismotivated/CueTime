<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}

// Include your database connection file
include('conn.php');

// Fetch username from the database based on the session user_id
$userId = $_SESSION['user_id']; // Get user ID from session
$username = 'Guest'; // Default username

// Query to get the username
$query = "SELECT username FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $userId);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Statistics | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <!-- Sccript ng chart -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  
  <!-- Calendar external css -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.css">

  <style>
/* Customize scrollbar track (background) */
::-webkit-scrollbar {
    width: 12px; /* Set width for vertical scrollbar */
    height: 12px; /* Set height for horizontal scrollbar */
}

/* Customize the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background-color: #888; /* Set thumb color */
    border-radius: 6px; /* Set thumb border radius */
    border: 3px solid #ccc; /* Optional: Set a border around the thumb */
}

/* Customize the scrollbar thumb when hovered */
::-webkit-scrollbar-thumb:hover {
    background-color: #555; /* Change thumb color on hover */
}

/* Customize scrollbar track (the area the thumb slides in) */
::-webkit-scrollbar-track {
    background-color: #f1f1f1; /* Set track background color */
    border-radius: 6px; /* Optional: Set track border radius */
}

/* Customize the scrollbar corner (where the horizontal and vertical scrollbars meet) */
::-webkit-scrollbar-corner {
    background-color: #f1f1f1; /* Set corner background color */
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    width: 100vw;
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

/* Calendar Styling */
#calendar {
    width: 100%;
    max-width: 900px;
    border-radius: 10px;
    padding: 5%;
}


.fc-button {
    /* Basic button styling */
    box-sizing: border-box;
    margin: 0;
    padding: 0.6em 1.2em; /* Adjust padding for sizing */
    font-size: 1em;
    cursor: pointer;
    background-color: transparent; /* Flat, light background */
    border: none; /* Subtle border for definition */
    color: #333; /* Neutral text color */
    text-align: center;
    font-weight: 400;
    border-radius: 3px; /* Rounded corners */
    transition: background-color 0.3s ease, border-color 0.3s ease; /* Smooth transitions for hover */
}

/* Default state (Normal button appearance) */
.fc-button.fc-state-default {
    background: transparent;
    border-color: #ddd;
    box-shadow: none; /* Removing any shadows */
}

/* Hover effect: Slight color change on hover */
.fc-button.fc-state-default:hover {
    background-color: #e0e0e0; /* Slight background color change on hover */
    border-color: #ccc; /* Lighter border color on hover */
}

/* Active state: Slightly darker background when clicked */
.fc-button.fc-state-active {
    background-color: #d5d5d5; /* Slightly darker background for active state */
    border-color: #bbb;
}

/* Disabled state: Lighter background and non-clickable button */
.fc-button.fc-state-disabled {
    background-color: #f5f5f5; /* Same as default background */
    color: #ccc; /* Lighter text */
    border-color: #ddd;
    cursor: not-allowed; /* Make it clear the button is not clickable */
}

.fc-button .fc-icon {
    text-shadow: none; /* Removing text shadow for icons */
}

/* Optional: Set minimalistic typography */
.fc-button span {
    font-family: 'Helvetica', sans-serif; /* Clean font for minimalistic look */
    letter-spacing: 0.5px; /* Slight letter spacing */
}

/* Optional: Borderless variant (for extreme minimalism) */
.fc-button.fc-state-borderless {
    background-color: transparent;
    border: none;
    color: #333;
}

/* Optional: Highlight state */
.fc-button.fc-state-highlight {
    background-color: #ffe0b2; /* A subtle highlight color */
    border-color: #ffcc80; /* Matching border color */
}

/* Optional: Larger padding for more prominent buttons */
.fc-button.fc-size-large {
    padding: 0.8em 1.5em;
    font-size: 1.2em;
}

.calendar-container {
    position: relative;
    width: 40%;
    height: calc(100% - 5vh);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #eee;
    border-radius: 10px;
    box-shadow: 2px 2px 4px rgba(0,0,0,0.125);
    overflow: hidden;
}

.calendar-design{
  position: absolute;
  top: -30%;
  width: 100%;
  height: 50%;
  background-color: #e3af12;
  border-radius: 50% / 10%;
}

#calendar{
  z-index: 1;
}

.fc-toolbar{
  color: white;
  position: absolute;
  top: 5vh;
  display: flex;
  justify-content: space-between;
  width: 100%;
}

.fc-right{
  position: absolute;
  top: 5vh;
}

.bottom-design{
  position: absolute;
  bottom: -30%;
  left: 0;
  width: 100%;
  height: 50%;
  background-color: #e3af12;
  border-radius: 50% / 10%;
}

  </style>

</head>

<?php
// Include your database connection file

// Check if the connection is successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

function getTotalHoursToday($table, $dateColumn) {
    global $conn;

    // Query to sum hours for today based on the given table and date column
    $query = "SELECT SUM(hours) AS total_hours FROM $table WHERE DATE($dateColumn) = CURDATE()";
    
    // Run the query
    $result = mysqli_query($conn, $query);
    
    // Check for query errors
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the total hours
    $row = mysqli_fetch_assoc($result);
    
    return $row['total_hours'] ? $row['total_hours'] : 0; // Return 0 if no data is found
}

// Fetch total hours for today
$walkInHoursToday = getTotalHoursToday('walk_in_registration', 'registration_date');
$reservationHoursToday = getTotalHoursToday('reservations', 'reservation_date');

// Calculate total hours for today (both walk-ins and reservations)
$totalHoursToday = $walkInHoursToday + $reservationHoursToday;

// Assign variables to use them directly
$walkInToday = $walkInHoursToday;            // Walk-in hours today
$reservationToday = $reservationHoursToday; // Reservation hours today
$totalToday = $totalHoursToday;             // Total hours today (combined)

function getTotalCustomersToday() {
    global $conn;

    $today = date('Y-m-d');

    // Query to count today's customers in both tables
    $query_walk_in = "SELECT COUNT(id) AS total_today FROM walk_in_registration WHERE DATE(registration_date) = ?";
    $query_reservations = "SELECT COUNT(id) AS total_today FROM reservations WHERE DATE(reservation_date) = ?";

    // Prepare and execute the queries
    $stmt_walk_in = $conn->prepare($query_walk_in);
    $stmt_walk_in->bind_param('s', $today);
    $stmt_walk_in->execute();
    $stmt_walk_in->bind_result($walkInToday);
    $stmt_walk_in->fetch();
    $stmt_walk_in->close();

    $stmt_reservations = $conn->prepare($query_reservations);
    $stmt_reservations->bind_param('s', $today);
    $stmt_reservations->execute();
    $stmt_reservations->bind_result($reservationsToday);
    $stmt_reservations->fetch();
    $stmt_reservations->close();

    return $walkInToday + $reservationsToday;
}

// Assign today's total customers to the variable
$totalCustomersToday = getTotalCustomersToday();

function getTotalRevenueToday() {
    global $conn;

    // Get today's date in 'YYYY-MM-DD' format
    $today = date('Y-m-d');

    // Query to sum hours for today's walk-in registrations
    $query_walk_in = "SELECT SUM(hours) AS total_hours FROM walk_in_registration WHERE DATE(registration_date) = ?";
    $query_reservations = "SELECT SUM(hours) AS total_hours FROM reservations WHERE DATE(reservation_date) = ?";
    
    // Prepare and execute walk-in query
    $stmt_walk_in = $conn->prepare($query_walk_in);
    $stmt_walk_in->bind_param('s', $today);
    $stmt_walk_in->execute();
    $result_walk_in = $stmt_walk_in->get_result();
    $row_walk_in = $result_walk_in->fetch_assoc();
    $stmt_walk_in->close();

    // Prepare and execute reservations query
    $stmt_reservations = $conn->prepare($query_reservations);
    $stmt_reservations->bind_param('s', $today);
    $stmt_reservations->execute();
    $result_reservations = $stmt_reservations->get_result();
    $row_reservations = $result_reservations->fetch_assoc();
    $stmt_reservations->close();

    // Calculate total revenue for today (100 PHP per hour)
    $totalRevenueToday = ($row_walk_in['total_hours'] + $row_reservations['total_hours']) * 100;

    return $totalRevenueToday;
}

$totalRevenueToday = getTotalRevenueToday();

?>

<body>
    <!-- Sidebar Section -->
    <?php include('sidebar.php'); ?>
    <!-- Sidebar Section -->

    <!-- MAIN CONTENT -->


    <!-- MAIN CONTENT -->
    <div style="display: flex; flex-grow: 1; gap: 2.5vh; padding: 0 2.5vh; height: 100%; justify-content: space-evenly; align-items: center;  background: linear-gradient(to bottom, #102820, #0c2a29, #081f1f, #061b1b);">
        <div style="max-width: 500px; position: relative; overflow: hidden; display: flex; flex-direction: column; flex-grow: 1; height: calc(100% - 5vh); width: 100%; background: #eee; box-shadow: 2px 2px 4px rgba(0,0,0,0.125); padding: 30px; border-radius:10px;">
            <div style="font-size: 32px; font-weight: 700;  margin-bottom: 25px; color: #fec107;">
            <p>Hello, <?php echo htmlspecialchars($username); ?>!</p>
            </div>

            <div style="display:flex; width: 100%; justify-content:space-between;">
                
                <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
                    <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Total Customers Today</label>
                    <input type="text" readonly value="<?php echo isset($totalCustomersToday) ? $totalCustomersToday : '0'; ?>" 
                           style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
                </div>  

                <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
                    <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Total Revenue Today</label>
                    <input type="text" readonly value="₱<?php echo isset($totalRevenueToday) ? number_format($totalRevenueToday, 2) : '0.00'; ?>" 
                           style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
                </div>

                
            </div>

            <div style="display:flex; width: 100%; justify-content:space-between;">
                
                <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
                    <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Walk-in Hours Today</label>
                    <input type="text" readonly value="<?php echo isset($walkInToday) ? $walkInToday : '0'; ?>" 
                           style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
                </div>  

                <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
                    <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Reserved Hours Today</label>
                    <input type="text" readonly value="<?php echo isset($reservationToday) ? number_format($reservationToday) : '0.00'; ?>" 
                           style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
                </div>

                
            </div>

            <canvas id="myChart" style="width:100%;max-width:600px"></canvas>
            <div class="bottom-design"></div>
        </div>

        <div class="calendar-container">
        <div class="calendar-design"></div>
                <div id="calendar"></div>
        </div>

    </div>

    <!-- MAIN CONTENT -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let sidebar = document.querySelector(".sidebar");
            let closeBtn = document.querySelector("#btn");

            // Toggle sidebar visibility on button click
            closeBtn.addEventListener("click", () => {
                sidebar.classList.toggle("open");
            });

            // Logout Confirmation Script
            document.getElementById('log_out').addEventListener('click', function (e) {
                e.preventDefault(); // Prevent default link action
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You will be logged out.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, log me out!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logout.php'; // Redirect to logout page
                    }
                    // Do nothing on cancel, avoiding layout recalculation
                });
            });
        });
    </script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>

<script>
 $('#calendar').fullCalendar({
    header: {
        left: 'title',
        right: 'month,agendaWeek,agendaDay, prev,next',
    },
    
    defaultView: 'agendaDay',
    defaultDate: new Date().toISOString().split('T')[0], // Set default date to today
    navLinks: true, // Enable navigation by clicking day/week names
    editable: false, // Disable event moving
    eventLimit: true, // Show "more" link when too many events
    timeZone: 'local', // Use the user's local timezone
    events: function(start, end, timezone, callback) {
        $.ajax({
            url: 'get_events.php', // Fetch events from the server
            dataType: 'json',
            success: function(data) {
                console.log(data); // Log the fetched data for debugging
                var events = data.map(function(event) {
                    return {
                        title: event.title,
                        start: moment(event.start).format("YYYY-MM-DDTHH:mm"),
                        end: moment(event.end).format("YYYY-MM-DDTHH:mm"),
                        description: event.description,
                        backgroundColor: "#155843"
                    };
                });
                callback(events); // Pass the formatted events to FullCalendar
            },
            error: function(xhr, status, error) {
                console.error("Error fetching events:", status, error);
            }
        });
    },
    eventClick: function(event) {
    const startTime = moment(event.start).format('hh:mm A'); // Format with AM/PM
    const endTime = event.end ? moment(event.end).format('hh:mm A') : 'N/A'; // Check if end time exists

    Swal.fire({
        title: event.title,
        html: `<p>${startTime} - ${endTime}</p> 
               <p>${event.description || 'No description available'}</p>`,
        icon: 'info',
    });
}

});


</script>

<script>
    // Pass the total hours for walk-ins and reservations
    const walkInHours = <?php echo json_encode($walkInToday); ?>;
    const reservationsHours = <?php echo json_encode($reservationToday); ?>;

    new Chart("myChart", {
        type: "bar", // Bar chart to display total sum
        data: {
            labels: ["Walk-in Registration", "Reservations"], // Only two labels for each category
            datasets: [
                {
                    label: "Total Hours",
                    backgroundColor: [" #155843", "#e3af12"], // Different colors for each
                    data: [walkInHours, reservationsHours], // Array with total hours for walk-ins and reservations
                },
            ],
        },
        options: {
            responsive: true,
            legend: { display: false }, // Hide legend if not needed
            scales: {
                yAxes: [
                    {
                        ticks: { min: 0, stepSize: 1 },
                        scaleLabel: {
                            display: true,
                            labelString: "Total Hours", // Label for the Y-axis
                        },
                    },
                ],
            },
        },
    });
</script>


</body>

</html>