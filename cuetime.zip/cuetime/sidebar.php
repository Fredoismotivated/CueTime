<?php
// sidebar.php
?>
<style>
.sidebar {
    height: 100vh; /* Make sidebar height fixed */
    display: flex;
    flex-direction: column;
    width: 78px;
    background: #155843;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    width: calc(100%-14px);
    display: flex;
    margin: 0px 14px;
    align-items: center;
    justify-content: center;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    width: 0;
    height: 20px;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open .profile .log_out,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
    width: 100%;
}

.sidebar.open .i,
.sidebar.open .logo-details #btn {
    text-align: end;
}

.sidebar .logo-details #btn {
    font-size: 22px;
    flex-grow: 1;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    height: 100%;
    margin: 6px 14px;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.active a {
    background: #eee !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }


    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }
}

.sidebar .profile {
    width: 100%;
    height: 72px;
    background-color: black;
}

#log_out-container {
    background-color: black;
    height: 60px;
    width: calc(100%-14px);
    display: flex;
    margin: 0px 14px;
    align-items: center;
    justify-content: center;
}

#log_out-container i{
    font-size: 22px;
    flex-grow: 1;
    cursor: pointer;
    transition: all 0.5s ease;
}

.log_out{
    color: #fff;
    width: 0;
    height: 18px;
    font-size: 16px;
    opacity: 0;
    transition: all 0.5s ease;
    overflow: hidden;
}

</style>

<div class="sidebar">
    <div class="logo-details">
        <div class="logo_name">Buchet Billiard</div>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list">
        
        <li class="<?php echo (basename($_SERVER['PHP_SELF']) === 'dashboard.php') ? 'active' : ''; ?>"> 
            <a href="dashboard.php">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
        </li> 

        <li class="<?php echo (basename($_SERVER['PHP_SELF']) === 'registrationForm.php') ? 'active' : ''; ?>">
            <a href="registrationForm.php">
                <i class='bx bxs-bookmark-alt-plus'></i>
                <span class="links_name">Registration</span>
            </a>    
        </li>

        <li class="<?php echo (basename($_SERVER['PHP_SELF']) === 'analytics.php') ? 'active' : ''; ?>">
            <a href="analytics.php">
                <i class='bx bxs-bar-chart-square'></i>
                <span class="links_name">Analytics</span>
            </a>
        </li>
        
    </ul>
    <div class="profile">
            <div id="log_out-container">
                <div class="log_out">Log Out</div>
                <i class='bx bx-log-out' id="log_out"></i>
            </div>
    </div>
</div>
