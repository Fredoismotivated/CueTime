<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// CORS Handling: Allow requests from all origins during development (adjust for production)
header("Access-Control-Allow-Origin: *"); // You can replace '*' with a specific domain for security
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Max-Age: 86400"); // Cache preflight response for 1 day

// Handle OPTIONS (Preflight) request for CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    // End preflight request and return early
    exit(0);
}

// Include the database connection
include('conn.php');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo json_encode(['error' => 'Passwords do not match']);
        exit();
    }

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(['error' => 'Username already exists']);
        exit();
    }

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert the user into the database
    $stmt = $conn->prepare("INSERT INTO users (username, password, signup_time) VALUES (?, ?, NOW())");
    $stmt->bind_param("ss", $username, $hashed_password);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Sign up successful']);
    } else {
        echo json_encode(['error' => 'Error: ' . $stmt->error]);
    }

    // Close the prepared statement and connection
    $stmt->close();
    $conn->close();
}
?>
