<?php
header('Content-Type: application/json');

date_default_timezone_set('Asia/Manila');

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Validate the data
if (
    !isset($data['firstName']) || empty(trim($data['firstName'])) ||
    !isset($data['lastName']) || empty(trim($data['lastName'])) ||
    !isset($data['phoneNumber']) || empty(trim($data['phoneNumber'])) ||
    !isset($data['tableSelect']) || empty(trim($data['tableSelect'])) ||
    !isset($data['reservationDate']) || empty(trim($data['reservationDate'])) ||
    !isset($data['hoursSelect']) || !is_numeric($data['hoursSelect']) ||
    !isset($data['paymentMethod']) || empty(trim($data['paymentMethod']))
) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required and must be valid.']);
    exit();
}

// Database connection (using conn.php file)
require_once 'conn.php';

// Sanitize inputs
$firstName = mysqli_real_escape_string($conn, trim($data['firstName']));
$lastName = mysqli_real_escape_string($conn, trim($data['lastName']));
$phoneNumber = mysqli_real_escape_string($conn, trim($data['phoneNumber']));
$tableSelect = mysqli_real_escape_string($conn, trim($data['tableSelect']));
$reservationDate = mysqli_real_escape_string($conn, trim($data['reservationDate']));
$hoursSelect = (int)$data['hoursSelect']; // Ensure hoursSelect is an integer
$paymentMethod = mysqli_real_escape_string($conn, trim($data['paymentMethod']));

// Validate phone number format (Philippines format: starts with 09 and is 11 digits)
if (!preg_match('/^\b09\d{9}\b/', $phoneNumber)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid phone number. Use 11 digits starting with 09.']);
    exit();
}

// Parse and validate reservation date
$reservationDateTime = strtotime($reservationDate);
if (!$reservationDateTime || $reservationDateTime <= time()) {
    echo json_encode(['status' => 'error', 'message' => 'Reservation date must be a valid future date.']);
    exit();
}

// Format reservation date and calculate end time
$reservationDateFormatted = date('Y-m-d H:i:s', $reservationDateTime); // Use 24-hour format for better consistency
$endTime = date('Y-m-d H:i:s', strtotime("+{$hoursSelect} hours", $reservationDateTime));

// Check for overlapping reservations for the same table in 'customers' table
$overlapQuery = "
    SELECT * FROM customers WHERE table_no = '$tableSelect' AND (
        ('$reservationDateFormatted' < end_time AND '$endTime' > start_time)
    )
";

$checkResult = mysqli_query($conn, $overlapQuery);

if (mysqli_num_rows($checkResult) > 0) {
    // Overlap detected
    echo json_encode(['status' => 'error', 'message' => 'The selected table is already reserved for the chosen time. Please choose a different table or time.']);
    exit();
}

// Insert reservation into the 'customers' table if no conflict is found
$query = "INSERT INTO customers (first_name, last_name, phone_number, table_no, reservation_date, start_time, end_time, hours, payment_method, entry_type) 
          VALUES ('$firstName', '$lastName', '$phoneNumber', '$tableSelect', '$reservationDateFormatted', '$reservationDateFormatted', '$endTime', '$hoursSelect', '$paymentMethod', 'reservation')";

$result = mysqli_query($conn, $query);

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Reservation successful.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . mysqli_error($conn)]);
}

mysqli_close($conn);
?>
