<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>AccountCenter | Cue Time</title>
  <link rel="icon" href="assets/Images/Logo.png" type="image/png" sizes="16x16">
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
</head>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;900&display=swap');

input {
  caret-color: red;
}

body {
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  font-family: 'Jost', sans-serif;
  background: linear-gradient(to bottom, #102820, #0c2a29, #081f1f, #061b1b);
}

html {
  overflow-y: scroll; /* Always show scrollbar */
}

.container {
  position: relative;
  display: flex;
  flex-direction: column; 
  align-items: center;
  width: 480px;
  height: 580px;
  border-radius: 10px;
  box-sizing: border-box;
  background:  #fec107;
  box-shadow: 5px 20px 50px #000;
  overflow: hidden;
}


.brand-title {
  font-weight: 900;
  font-size: 2.3rem;
  color: white;
  letter-spacing: 1px;
  flex-grow: 1;
  display: flex;
  align-items: center;
}

.inputs {
  display: flex;
  flex-direction: column;
  justify-content: start;
  width:100%;
  height: 70%;
}

form{
  display: flex;
  justify-content: center;
}

label, input, button {
  display: block;
  width: 100%;
  padding: 0;
  border: none;
  outline: none;
  box-sizing: border-box;
}

input::placeholder {
  color: gray;
}

input {
  background: #ecf0f3;
  padding: 20px;
  height: 18px;
  font-size: 14px;
  border-radius: 5px;
  width: 100%;
  margin: 10px 0;
}

.confirm-button {
  position: absolute;
  bottom: -30%;
  color: gray;
  margin-top: 12px;
  background-color:  white;
  height: 50%;
  width: 100%;
  cursor: pointer;
  font-weight: 600;
  font-size: 1.6em ;
  transition: 0.5s;
  border-radius:50% / 10%;
  transition: 0.8s ease-in-out;
  padding-bottom: 35%;
}

button:hover {
  transform: scale(1.1);
}

/* Style for the "Back" button link */
#back-button {
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;
  right: 2vh;
  top: 2vh;
  font-size: 24;
  height: 30px;
  width: 30px;
  border-radius: 5px;
  text-decoration: none;
}

#back-button i {
  font-size: 1.3em; /* Adjust the icon size here */
}

#back-button:hover {
  background: white;
}

 /* Para sa password visibility */
 .password-container {
    position: relative;
    width: 100%;
  }

  .toggle-visibility {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    width: 20px;
    height: 20px;
    background-color: #eee;
  }

  .form-container{
    width: 60%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }
</style>

<body>
<div class="container">
  <a href="index.php" id="back-button"><i class="bx bx-chevron-left"></i></a>
  <div class="brand-title">Change Password</div>
  <div class="inputs">
    <form action="update_password.php" method="POST" id="password-form">
      <div class="form-container">
        <input type="text" name="username" placeholder="Username" required />
        <div class="password-container">
          <input type="password" name="password" id="password" placeholder="New Password" required />
          <img class="toggle-visibility" src="assets/Images/hide.png" onclick="togglePasswordVisibility('password')" alt="Show Password" />
        </div>
        <div class="password-container">
          <input type="password" name="confirm-password" id="confirm-password" placeholder="Confirm New Password" required />
          <img class="toggle-visibility" src="assets/Images/hide.png" onclick="togglePasswordVisibility('confirm-password')" alt="Show Confirm Password" />
        </div>
      </div>
      <button type="submit" class="confirm-button">Confirm</button>
    </form>
  </div>
</div>

<script>
  function togglePasswordVisibility(id) {
    var passwordField = document.getElementById(id);
    var toggleIcon = passwordField.nextElementSibling;
    var type = passwordField.type === "password" ? "text" : "password";
    passwordField.type = type;
    toggleIcon.src = type === "password" ? "assets/Images/hide.png" : "assets/Images/show.png";
  }

  // Form submission handling with SweetAlert messages
  document.getElementById('password-form').onsubmit = function(event) {
  event.preventDefault();
  const form = event.target;
  const formData = new FormData(form);

  fetch('update_password.php', {
    method: 'POST',
    body: formData
  }).then(response => response.json())
    .then(data => {
      if (data.success) {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: data.success,
        }).then(() => {
          // Clear the text fields after success
          document.getElementById('password').value = '';
          document.getElementById('confirm-password').value = '';
          
          // Redirect to index.php after clearing fields
          window.location.href = "index.php";
        });
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: data.error,
        });
      }
    }).catch((error) => {
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: `An error occurred: ${error.message}`,
      });
    });
};

</script>


</body>
</html>