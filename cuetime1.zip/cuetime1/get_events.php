<?php
// Include database connection
include 'conn.php';

// Query to get events from both tables (handle start_time and end_time for walk_in_registration)
$query = "
    SELECT 
        id, CONCAT(first_name, ' ', last_name) AS title, start_time AS start, end_time AS end, 'Walk-in Registration' AS description
    FROM 
        walk_in_registration
    WHERE start_time IS NOT NULL AND end_time IS NOT NULL
    UNION
    SELECT 
        id, CONCAT(first_name, ' ', last_name) AS title, start_time AS start, end_time AS end, 'Reservation' AS description
    FROM 
        reservations
    WHERE start_time IS NOT NULL AND end_time IS NOT NULL
";

// Execute query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if (!$result) {
    // Output the error message
    die('Query failed: ' . mysqli_error($conn));
}

// Initialize an empty array for events
$events = [];

// Fetch all events from both tables
while ($row = mysqli_fetch_assoc($result)) {
    // You may want to format start_time and end_time to a specific format (e.g., using MySQL's datetime format)
    $events[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'start' => $row['start'],
        'end' => $row['end'],
        'description' => $row['description']
    ];
}

// Return the events as a JSON response
echo json_encode($events);
?>
