<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>Schedules | Cue Time</title>
<link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

<!-- Import Boxicons -->
<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

<!-- Import SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

<!-- Calendar External CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.css">

<!-- Internal CSS -->
<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh; /* Ensure the entire page fits within the viewport */
    width: 100vw;
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

/* Main Content */
main {
    flex-grow: 1;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Calendar Styling */
#calendar {
    width: 100%;
    max-width: 900px;
    border-radius: 10px;
    background-color: white;
    padding: 5%;
}


.fc-button {
    /* Basic button styling */
    box-sizing: border-box;
    margin: 0;
    padding: 0.6em 1.2em; /* Adjust padding for sizing */
    font-size: 1em;
    cursor: pointer;
    background-color: #f5f5f5; /* Flat, light background */
    border: 1px solid #ddd; /* Subtle border for definition */
    color: #333; /* Neutral text color */
    text-align: center;
    font-weight: 400;
    border-radius: 3px; /* Rounded corners */
    transition: background-color 0.3s ease, border-color 0.3s ease; /* Smooth transitions for hover */
}

/* Default state (Normal button appearance) */
.fc-button.fc-state-default {
    background: #f5f5f5;
    border-color: #ddd;
    box-shadow: none; /* Removing any shadows */
}

/* Hover effect: Slight color change on hover */
.fc-button.fc-state-default:hover {
    background-color: #e0e0e0; /* Slight background color change on hover */
    border-color: #ccc; /* Lighter border color on hover */
}

/* Active state: Slightly darker background when clicked */
.fc-button.fc-state-active {
    background-color: #d5d5d5; /* Slightly darker background for active state */
    border-color: #bbb;
}

/* Disabled state: Lighter background and non-clickable button */
.fc-button.fc-state-disabled {
    background-color: #f5f5f5; /* Same as default background */
    color: #ccc; /* Lighter text */
    border-color: #ddd;
    cursor: not-allowed; /* Make it clear the button is not clickable */
}

/* Tagline classes: Button with specific additional styles */
.fc-button.fc-corner-left,
.fc-button.fc-corner-right {
    border-radius: 0; /* Remove corners for left or right corners */
}

.fc-button .fc-icon {
    text-shadow: none; /* Removing text shadow for icons */
}

/* Optional: Set minimalistic typography */
.fc-button span {
    font-family: 'Helvetica', sans-serif; /* Clean font for minimalistic look */
    letter-spacing: 0.5px; /* Slight letter spacing */
}

/* Optional: Borderless variant (for extreme minimalism) */
.fc-button.fc-state-borderless {
    background-color: transparent;
    border: none;
    color: #333;
}

/* Optional: Highlight state */
.fc-button.fc-state-highlight {
    background-color: #ffe0b2; /* A subtle highlight color */
    border-color: #ffcc80; /* Matching border color */
}

/* Optional: Larger padding for more prominent buttons */
.fc-button.fc-size-large {
    padding: 0.8em 1.5em;
    font-size: 1.2em;
}

.calendar-container {
    width: 50%;
}

</style>

</head>

<body>
<!-- Sidebar Section -->
<?php include('sidebar.php'); ?>
<!-- Sidebar Section -->
<!-- Main Content -->
<main>
    <div class="calendar-container">
        <div id="calendar"></div>
    </div>
</main>

<!-- External Scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>

<script>
 $('#calendar').fullCalendar({
    header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay',
    },
    defaultDate: new Date().toISOString().split('T')[0], // Set default date to today
    navLinks: true, // Enable navigation by clicking day/week names
    editable: false, // Disable event moving
    eventLimit: true, // Show "more" link when too many events
    timeZone: 'local', // Use the user's local timezone
    events: function(start, end, timezone, callback) {
        $.ajax({
            url: 'get_events.php', // Fetch events from the server
            dataType: 'json',
            success: function(data) {
                console.log(data); // Log the fetched data for debugging
                var events = data.map(function(event) {
                    return {
                        title: event.title,
                        start: moment(event.start).format("YYYY-MM-DDTHH:mm"),
                        end: moment(event.end).format("YYYY-MM-DDTHH:mm"),
                        description: event.description
                    };
                });
                callback(events); // Pass the formatted events to FullCalendar
            },
            error: function(xhr, status, error) {
                console.error("Error fetching events:", status, error);
            }
        });
    },
    eventClick: function(event) {
    const startTime = moment(event.start).format('hh:mm A'); // Format with AM/PM
    const endTime = event.end ? moment(event.end).format('hh:mm A') : 'N/A'; // Check if end time exists

    Swal.fire({
        title: event.title,
        html: `<p>${startTime} - ${endTime}</p> 
               <p>${event.description || 'No description available'}</p>`,
        icon: 'info',
    });
}

});


</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>
</body>
</html>
