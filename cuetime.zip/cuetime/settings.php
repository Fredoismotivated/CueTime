<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}

// Include your database connection file
include('conn.php');

// Fetch username from the database based on the session user_id
$userId = $_SESSION['user_id']; // Get user ID from session
$username = 'Guest'; // Default username

// Query to get the username
$query = "SELECT username FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $userId);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Statistics | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <!-- Sccript ng chart -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    width: 100vw;
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

.sidebar {
    height: 100vh; /* Make sidebar height fixed */
    width: 78px;
    background: #155843;
    padding: 6px 14px;
    z-index: 1;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
}

.sidebar.open .logo-details,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
}

.sidebar .logo-details #btn {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    font-size: 22px;
    text-align: center;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    margin-top: 20px;
    height: 100%;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li.profile {
    position: fixed;
    height: 60px;
    width: 78px;
    left: 0;
    bottom: -8px;
    padding: 10px 14px;
    background: #1d1b31;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open li.profile {
    width: 250px;
}

.sidebar li .profile-details {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.profile .name,
.sidebar li.profile .job {
    font-size: 15px;
    font-weight: 400;
    color: #fff;
    white-space: nowrap;
}

.sidebar li.profile .job {
    font-size: 12px;
}

.sidebar li.profile #log_out {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    background: #1d1b31;
    width: 100%;
    height: 60px;
    line-height: 60px;
    transition: all 0.5s ease;
}


.sidebar.open .profile #log_out {
    width: 30px;
    background: none;
}

.sidebar li.active a {
    background: #fff !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */
    .sidebar li .profile .name {
        font-size: calc(1.5vw + 10px); /* Adjust profile name font size */
    }

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */
    .sidebar li.profile #log_out {
        width: auto; /* Allow the button to only take up space for the icon */
        background-color: transparent; /* Match sidebar background */
        border-top: none; /* Remove top border */
        padding: 10px; /* Add padding for consistent spacing */
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align the logout icon to the left */
    }

    .sidebar li.profile #log_out i.bx.box-log-out {
        font-size: calc(2vw + 1px); /* Keep icon size consistent */
        color: #fff; /* Match icon color with other sidebar items */
        margin-right: 10px; /* Add some space between the icon and any text */
    }

    /* Profile section width adjustment */
    .sidebar li.profile {
        width: 9.2vh; /* padding to sa logout button para pantay lang sa navbar */
    }

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }

    /* Hide the "Cue Time" and "By Group:" text */
    .sidebar .profile .name,
    .sidebar .profile .job {
        display: none !important; /* Ensure these elements are hidden */
    }

    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }/* NAV BAR SA GILID END */

}

.main {
  width: 350px;
  height: 500px;
  overflow: hidden;
  background-color: #e3af12;
  border-radius: 10px;
  box-shadow: 5px 20px 50px #000;
}

/* Hide checkbox used for toggling forms */
#chk {
  display: none;
}

/* Signup and login forms */
.signup, .login {
  position: relative;
  width: 100%;
  height: 100%;
}

label {
  color: #fff;
  font-size: 2.3em;
  justify-content: center;
  display: flex;
  margin: 50px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.5s ease-in-out;
}

/* Input fields */
.input-container {
  width: 60%;
  margin: 20px auto;
  position: relative;
  background-color: #e0dede;
  border-radius: 5px;
}

input {
  height: 10px;
  background: transparent;
  padding: 12px;
  border: none;
  outline: none;
}

/* Password container for toggle */
.password-container {
  position: relative;
}

.password-toggle {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  cursor: pointer;
  width: 24px; /* Adjust size of the image */
  height: 24px;
}

.password-toggle img {
  width: 100%;
  height: 100%;
  object-fit: contain; /* Ensure image doesn't stretch */
}

/* Buttons */
button {
  width: 60%;
  height: 40px;
  margin: 10px auto;
  justify-content: center;
  display: block;
  color: #fff;
  background: #24231f;
  font-size: 1em;
  font-weight: bold;
  margin-top: 30px;
  outline: none;
  border: none;
  border-radius: 5px;
  transition: 0.2s ease-in;
  cursor: pointer;
}

button:hover {
  background: #4a4841;
}

/* Login form animation */
.login {
  height: 460px;
  background: #eee;
  border-radius: 60% / 10%;
  transform: translateY(-180px);
  transition: 0.8s ease-in-out;
}

.login label {
  color: gray;
  transform: scale(0.6);
}

/* Checkbox toggle behavior */
#chk:checked ~ .login {
  transform: translateY(-500px);
}

#chk:checked ~ .login label {
  transform: scale(1);
}

#chk:checked ~ .signup label {
  transform: scale(0.6);
}

/* Responsive styling for tablets and desktops */
@media (min-width: 768px) {
  .main {
    width: 450px;
  }
}

@media (min-width: 1024px) {
  .main {
    width: 450px;
    height: 540px;
  }
}

  </style>

</head>

<body>
    <!-- Sidebar Section -->
    <?php include('sidebar.php'); ?>
    <!-- Sidebar Section -->

    <!-- MAIN CONTENT -->
<?php
// Include your database connection file

// Check if the connection is successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Function to get total hours from each table (walk-in and reservations)
function getTotalHoursPerMonth($table, $dateColumn) {
    global $conn;
    // Modify the query to use the correct date column and sum hours
    $query = "SELECT MONTH($dateColumn) AS month, SUM(hours) AS total_hours FROM $table GROUP BY MONTH($dateColumn)";
    
    // Run the query
    $result = mysqli_query($conn, $query);
    
    // Check for query errors
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }

    $months = [];
    $hours = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $months[] = $row['month'];
        $hours[] = $row['total_hours'];
    }

    return ['months' => $months, 'hours' => $hours];
}

// Fetch data for both tables
$walkInData = getTotalHoursPerMonth('walk_in_registration', 'registration_date');
$reservationsData = getTotalHoursPerMonth('reservations', 'reservation_date');

// Function to get total customers by counting the records in both tables
function getTotalCustomers() {
    global $conn;
    
    // Query to get the total number of customers in both tables
    $query_walk_in = "SELECT COUNT(id) AS total_customers FROM walk_in_registration";
    $query_reservations = "SELECT COUNT(id) AS total_customers FROM reservations";
    
    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Calculate total customers by adding counts from both tables
    $totalCustomer = $row_walk_in['total_customers'] + $row_reservations['total_customers'];

    return $totalCustomer;
}

// Assign the total customer count to the variable
$totalCustomer = getTotalCustomers();

// Function to get total revenue by summing hours and multiplying by 100 PHP per hour
function getTotalRevenue() {
    global $conn;

    // Query to sum hours for both tables
    $query_walk_in = "SELECT SUM(hours) AS total_hours FROM walk_in_registration";
    $query_reservations = "SELECT SUM(hours) AS total_hours FROM reservations";
    
    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Calculate total revenue (100 PHP per hour)
    $totalRevenue = ($row_walk_in['total_hours'] + $row_reservations['total_hours']) * 100;

    return $totalRevenue;
}

// Assign the total revenue to the variable
$totalRevenue = getTotalRevenue();
function getTotalCustomersToday() {
    global $conn;

    $today = date('Y-m-d');

    // Query to count today's customers in both tables
    $query_walk_in = "SELECT COUNT(id) AS total_today FROM walk_in_registration WHERE DATE(registration_date) = ?";
    $query_reservations = "SELECT COUNT(id) AS total_today FROM reservations WHERE DATE(reservation_date) = ?";

    // Prepare and execute the queries
    $stmt_walk_in = $conn->prepare($query_walk_in);
    $stmt_walk_in->bind_param('s', $today);
    $stmt_walk_in->execute();
    $stmt_walk_in->bind_result($walkInToday);
    $stmt_walk_in->fetch();
    $stmt_walk_in->close();

    $stmt_reservations = $conn->prepare($query_reservations);
    $stmt_reservations->bind_param('s', $today);
    $stmt_reservations->execute();
    $stmt_reservations->bind_result($reservationsToday);
    $stmt_reservations->fetch();
    $stmt_reservations->close();

    return $walkInToday + $reservationsToday;
}

// Assign the total customer count to the variable
$totalCustomer = getTotalCustomers();

// Assign today's total customers to the variable
$totalCustomersToday = getTotalCustomersToday();

function getTotalRevenueToday() {
    global $conn;

    // Get today's date in 'YYYY-MM-DD' format
    $today = date('Y-m-d');

    // Query to sum hours for today's walk-in registrations
    $query_walk_in = "SELECT SUM(hours) AS total_hours FROM walk_in_registration WHERE DATE(registration_date) = ?";
    $query_reservations = "SELECT SUM(hours) AS total_hours FROM reservations WHERE DATE(reservation_date) = ?";
    
    // Prepare and execute walk-in query
    $stmt_walk_in = $conn->prepare($query_walk_in);
    $stmt_walk_in->bind_param('s', $today);
    $stmt_walk_in->execute();
    $result_walk_in = $stmt_walk_in->get_result();
    $row_walk_in = $result_walk_in->fetch_assoc();
    $stmt_walk_in->close();

    // Prepare and execute reservations query
    $stmt_reservations = $conn->prepare($query_reservations);
    $stmt_reservations->bind_param('s', $today);
    $stmt_reservations->execute();
    $result_reservations = $stmt_reservations->get_result();
    $row_reservations = $result_reservations->fetch_assoc();
    $stmt_reservations->close();

    // Calculate total revenue for today (100 PHP per hour)
    $totalRevenueToday = ($row_walk_in['total_hours'] + $row_reservations['total_hours']) * 100;

    return $totalRevenueToday;
}

$totalRevenueToday = getTotalRevenueToday();

?>

    <!-- MAIN CONTENT -->
    <div class="signup">
      <form id="signup-form" onsubmit="return validatePassword(event)">
        <label for="chk" aria-hidden="true">Sign up</label>
        <div class="input-container">
          <input type="text" id="signup-username" name="username" placeholder="Username" required>
        </div>
        <div class="input-container password-container">
          <input type="password" id="signup-password" name="password" placeholder="Password" required>
          <span class="password-toggle" onclick="togglePasswordVisibility('signup-password', this)">
            <img src="assets/Images/hide.png" alt="Show password" id="signup-toggle-icon">
          </span>
        </div>
        <div class="input-container password-container">
          <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm Password" required>
          <span class="password-toggle" onclick="togglePasswordVisibility('confirm-password', this)">
            <img src="assets/Images/hide.png" alt="Show password" id="confirm-toggle-icon">
          </span>
        </div>
        <button type="submit">Sign up</button>
      </form>
    </div>
    </div>
    <!-- MAIN CONTENT -->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let sidebar = document.querySelector(".sidebar");
            let closeBtn = document.querySelector("#btn");

            // Toggle sidebar visibility on button click
            closeBtn.addEventListener("click", () => {
                sidebar.classList.toggle("open");
            });

            // Logout Confirmation Script
            document.getElementById('log_out').addEventListener('click', function (e) {
                e.preventDefault(); // Prevent default link action
                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You will be logged out.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, log me out!',
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'logout.php'; // Redirect to logout page
                    }
                    // Do nothing on cancel, avoiding layout recalculation
                });
            });
        });
    </script>
</body>

</html>