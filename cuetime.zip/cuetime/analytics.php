<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Statistics | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <!-- Sccript ng chart -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    width: 100vw;
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}


  </style>

</head>

<body>
<!-- Sidebar Section -->
<?php include('sidebar.php'); ?>
<!-- Sidebar Section -->

<!-- MAIN CONTENT -->
<?php
// Include your database connection file
include('conn.php');

// Check if the connection is successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Function to get total hours from each table (walk-in and reservations)
function getTotalHoursPerMonth($table, $dateColumn) {
    global $conn;
    // Modify the query to use the correct date column and sum hours
    $query = "SELECT MONTH($dateColumn) AS month, SUM(hours) AS total_hours FROM $table GROUP BY MONTH($dateColumn)";
    
    // Run the query
    $result = mysqli_query($conn, $query);
    
    // Check for query errors
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }

    $months = [];
    $hours = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $months[] = $row['month'];
        $hours[] = $row['total_hours'];
    }

    return ['months' => $months, 'hours' => $hours];
}

// Fetch data for both tables
$walkInData = getTotalHoursPerMonth('walk_in_registration', 'registration_date');
$reservationsData = getTotalHoursPerMonth('reservations', 'reservation_date');

// Function to get total customers by counting the records in both tables
function getCustomerCounts() {
    global $conn;

    // Query to get the total number of walk-in customers
    $query_walk_in = "SELECT COUNT(id) AS total_walk_in FROM walk_in_registration";
    
    // Query to get the total number of reserved customers
    $query_reservations = "SELECT COUNT(id) AS total_reserved FROM reservations";

    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Get the individual counts
    $totalWalkIn = $row_walk_in['total_walk_in'];
    $totalReserved = $row_reservations['total_reserved'];

    // Calculate the combined total customers
    $totalCustomer = $totalWalkIn + $totalReserved;

    // Return an associative array with all counts
    return [
        'totalWalkIn' => $totalWalkIn,
        'totalReserved' => $totalReserved,
        'totalCustomer' => $totalCustomer,
    ];
}

// Assign the returned array to a variable
$customerCounts = getCustomerCounts();

// Access the individual and combined counts
$totalWalkIn = $customerCounts['totalWalkIn'];
$totalReserved = $customerCounts['totalReserved'];
$totalCustomer = $customerCounts['totalCustomer'];

// Function to get total revenue by summing hours and multiplying by 100 PHP per hour
function getTotalRevenue() {
    global $conn;

    // Query to sum hours for both tables
    $query_walk_in = "SELECT SUM(hours) AS total_hours FROM walk_in_registration";
    $query_reservations = "SELECT SUM(hours) AS total_hours FROM reservations";
    
    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Calculate total revenue (100 PHP per hour)
    $totalRevenue = ($row_walk_in['total_hours'] + $row_reservations['total_hours']) * 100;

    return $totalRevenue;
}

// Assign the total revenue to the variable
$totalRevenue = getTotalRevenue();
?>

<div style="display: flex; flex-grow: 1; justify-content: space-evenly; align-items: center; min-height: 100vh; background: linear-gradient(to bottom, #102820, #0c2a29, #081f1f, #061b1b);">
  <div style="max-width: 500px; width: 100%; background: #eee; margin: 0; box-shadow: 2px 2px 4px rgba(0,0,0,0.125); padding: 30px; border-radius:10px;">
    <div style="font-size: 24px; font-weight: 700; margin-bottom: 25px; color: #fec107; text-transform: uppercase;">
      Analytics
    </div>
<div style="display:flex; width: 100%; justify-content:space-between;">
      <!-- Total Customer Field -->
      <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;"> Total Customer</label>
        <input type="text" readonly value="<?php echo isset($totalCustomer) ? $totalCustomer : '0'; ?>" 
               style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
      </div>

      <!-- Total Revenue Field -->
      <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Total Revenue</label>
        <input type="text" readonly value="₱<?php echo isset($totalRevenue) ? number_format($totalRevenue, 2) : '0.00'; ?>" 
               style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
      </div>
</div>

<div style="display:flex; width: 100%; justify-content:space-between;">
      <!-- Total Customer Field -->
      <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;"> Total Walk-in Customer</label>
        <input type="text" readonly value="<?php echo isset($totalWalkIn) ? $totalWalkIn : '0'; ?>" 
               style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
      </div>

      <!-- Total Revenue Field -->
      <div style="width: 48%; margin-bottom: 15px; display: flex; flex-direction: column; border: 1px solid #d5dbd9; border-radius: 3px; padding:10px;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Total Reserved Customer</label>
        <input type="text" readonly value="<?php echo isset($totalReserved) ? number_format($totalReserved) : '0.00'; ?>" 
               style="width: 100%; outline: none; border:none; font-size: 15px; padding: 8px 10px; transition: all 0.3s ease; cursor: default; background: #eee;">
      </div>
</div>

<canvas id="myChart" style="width:100%;max-width:600px"></canvas>

</div>

<script>
  // Labels for the hours 1 to 5

  // Example data for walk-ins and reservations per hour
  const walkInHours = <?php echo json_encode($walkInData['hours']); ?>; // Array with counts for each hour
  const reservationsHours = <?php echo json_encode($reservationsData['hours']); ?>; // Array with counts for each hour

  new Chart("myChart", {
    type: "bar", // Changed to bar for better visibility per hour
    data: {
      datasets: [
        {
          label: "Walk-in Registration",
          backgroundColor: "red",
          borderWidth: 2,
          data: walkInHours, // Data for each hour
        },
        {
          label: "Reservations",
          backgroundColor: "blue",
          borderWidth: 2,
          data: reservationsHours, // Data for each hour
        },
      ],
    },
    options: {
      responsive: true,
      legend: { display: true },
      scales: {
        yAxes: [
          {
            ticks: { min: 0, stepSize: 1 },
            scaleLabel: {
              display: true,
              labelString: "Total Hours",
            },
          },
        ],
      },
    },
  });
</script>

<!-- MAIN CONTENT -->

<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>


</body>

</html>