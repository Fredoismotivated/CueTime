<?php
require_once 'conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $startDate = $_GET['startDate'] ?? null;
    $endDate = $_GET['endDate'] ?? null;

    if (!$startDate || !$endDate) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid date range']);
        exit;
    }

    // Fetch pending reservations within the specified range
    $query = "
        SELECT first_name, last_name, table_no, start_time, end_time 
        FROM reservations 
        WHERE reservation_date BETWEEN ? AND ?
    ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();

    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }

    echo json_encode($reservations);
    $stmt->close();
    $conn->close();
}
?>
