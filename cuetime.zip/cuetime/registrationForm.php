<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Reservation | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.css">

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <style>
/* Customize scrollbar track (background) */
::-webkit-scrollbar {
    width: 12px; /* Set width for vertical scrollbar */
    height: 12px; /* Set height for horizontal scrollbar */
}

/* Customize the scrollbar thumb (the draggable part) */
::-webkit-scrollbar-thumb {
    background-color: #888; /* Set thumb color */
    border-radius: 6px; /* Set thumb border radius */
    border: 3px solid #ccc; /* Optional: Set a border around the thumb */
}

/* Customize the scrollbar thumb when hovered */
::-webkit-scrollbar-thumb:hover {
    background-color: #555; /* Change thumb color on hover */
}

/* Customize scrollbar track (the area the thumb slides in) */
::-webkit-scrollbar-track {
    background-color: #f1f1f1; /* Set track background color */
    border-radius: 6px; /* Optional: Set track border radius */
}

/* Customize the scrollbar corner (where the horizontal and vertical scrollbars meet) */
::-webkit-scrollbar-corner {
    background-color: #f1f1f1; /* Set corner background color */
}


* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    display: flex;
    width: 100vw;
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

main{
  display: flex;
  flex-grow: 1;
  align-items: center;
  justify-content: space-evenly;
  background: linear-gradient(to bottom, #102820, #0c2a29, #081f1f, #061b1b);
}

.main {
  width: 500px;
  height: calc(100% - 5vh);
  overflow: hidden;
  background-color: #e3af12;
  border-radius: 10px;
}

/* Hide checkbox used for toggling forms */
#chk {
  display: none;
}

/* Signup and login forms */
.walkIn, .reservation {
  position: relative;
  width: 100%;
  height: 100%;
}

label {
  color: #fff;
  font-size: 2.3em;
  justify-content: center;
  display: flex;
  margin: 50px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.5s ease-in-out;
}

/* Input fields */
.input-container {
  width: 60%;
  margin: 20px auto;
  position: relative;
  background-color: #e0dede;
  border-radius: 5px;
  padding: 5px;
}

input {
  height: 15px;
  font-size: 15px;
  background: transparent;
  border: none;
  outline: none;
}

.form-select{
  width: 100%;
  height: 15px;
  font-size: 15px;
  background: transparent;
  border: none;
  outline: none;
}

.form-button {
  width: 60%;
  height: 40px;
  margin: 10px auto;
  justify-content: center;
  display: block;
  color: #fff;
  background: #24231f;
  font-size: 1em;
  font-weight: bold;
  margin-top: 30px;
  outline: none;
  border: none;
  border-radius: 5px;
  transition: 0.2s ease-in;
  cursor: pointer;
}

.form-button:hover {
  background: #4a4841;
}

/* Login form animation */
.reservation {
  height: calc(100% - 5vh);
  background: #eee;
  border-radius: 60% / 10%;
  transform: translateY(-180px);
  transition: 0.8s ease-in-out;
}

.reservation label {
  color: gray;
  transform: scale(0.6);
  padding-top: 5vh;
}

/* Checkbox toggle behavior */
#chk:checked ~ .reservation {
  transform: translateY(calc(-100% - 5vh));
}

#chk:checked ~ .reservation label {
  transform: scale(1);
}

#chk:checked ~ .walkIn label {
  transform: scale(0.6);
}

/* Calendar Styling */
#calendar {
    width: 100%;
    max-width: 900px;
    border-radius: 10px;
    padding: 5%;
}


.fc-button {
    /* Basic button styling */
    box-sizing: border-box;
    margin: 0;
    padding: 0.6em 1.2em; /* Adjust padding for sizing */
    font-size: 1em;
    cursor: pointer;
    background-color: transparent; /* Flat, light background */
    border: none; /* Subtle border for definition */
    color: #333; /* Neutral text color */
    text-align: center;
    font-weight: 400;
    border-radius: 3px; /* Rounded corners */
    transition: background-color 0.3s ease, border-color 0.3s ease; /* Smooth transitions for hover */
}

/* Default state (Normal button appearance) */
.fc-button.fc-state-default {
    background: transparent;
    border-color: #ddd;
    box-shadow: none; /* Removing any shadows */
}

/* Hover effect: Slight color change on hover */
.fc-button.fc-state-default:hover {
    background-color: #e0e0e0; /* Slight background color change on hover */
    border-color: #ccc; /* Lighter border color on hover */
}

/* Active state: Slightly darker background when clicked */
.fc-button.fc-state-active {
    background-color: #d5d5d5; /* Slightly darker background for active state */
    border-color: #bbb;
}

/* Disabled state: Lighter background and non-clickable button */
.fc-button.fc-state-disabled {
    background-color: #f5f5f5; /* Same as default background */
    color: #ccc; /* Lighter text */
    border-color: #ddd;
    cursor: not-allowed; /* Make it clear the button is not clickable */
}

.fc-button .fc-icon {
    text-shadow: none; /* Removing text shadow for icons */
}

/* Optional: Set minimalistic typography */
.fc-button span {
    font-family: 'Helvetica', sans-serif; /* Clean font for minimalistic look */
    letter-spacing: 0.5px; /* Slight letter spacing */
}

/* Optional: Borderless variant (for extreme minimalism) */
.fc-button.fc-state-borderless {
    background-color: transparent;
    border: none;
    color: #333;
}

/* Optional: Highlight state */
.fc-button.fc-state-highlight {
    background-color: #ffe0b2; /* A subtle highlight color */
    border-color: #ffcc80; /* Matching border color */
}

/* Optional: Larger padding for more prominent buttons */
.fc-button.fc-size-large {
    padding: 0.8em 1.5em;
    font-size: 1.2em;
}

.calendar-container {
    position: relative;
    width: 40%;
    height: calc(100% - 5vh);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #eee;
    border-radius: 10px;
    box-shadow: 2px 2px 4px rgba(0,0,0,0.125);
    overflow: hidden;
}

.calendar-design{
  position: absolute;
  top: -30%;
  width: 100%;
  height: 50%;
  background-color: #e3af12;
  border-radius: 50% / 10%;
}

#calendar{
  z-index: 1;
}

.fc-toolbar{
  color: white;
  position: absolute;
  top: 5vh;
  display: flex;
  justify-content: space-between;
  width: 100%;
}

.fc-right{
  position: absolute;
  top: 5vh;
}

  </style>

</head>

<body>
<!-- Sidebar Section -->
<?php include('sidebar.php'); ?>
<!-- Sidebar Section -->
 
<!-- MAIN CONTENT -->
<main>

<div class="main">
  <input type="checkbox" id="chk" aria-hidden="true">

  <div class="walkIn">
  <label for="chk" aria-hidden="true">Walk-In</label>
  <form>
    <!-- First Name Field -->
    <div class="input-container">
      <input type="text" id="first_name" class="input-field" placeholder="Enter First Name">
    </div>

    <!-- Last Name Field -->
    <div class="input-container">
      <input type="text" id="last_name" class="input-field" placeholder="Enter Last Name">
    </div>

    <!-- Phone Number -->
    <div class="input-container">
      <input type="text" id="phone_number" class="input-field" placeholder="Enter Phone Number">
    </div>

    <!-- Table Selection -->
    <div class="input-container">
      <select id="table" class="form-select">
        <option value="">Select Table</option>
        <option value="1">1</option>
        <option value="2">2</option>
      </select>
    </div>

    <!-- Hours Selection -->
    <div class="input-container">
      <select id="hours" class="form-select">
        <option value="">Select Hours</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
    </div>

    <!-- Payment Method Selection -->
    <div class="input-container">
      <select id="payment_method" class="form-select">
        <option value="">Select Payment Method</option>
        <option value="Cash">Cash</option>
        <option value="G-Cash">G-Cash</option>
      </select>
    </div>

    <!-- Submit Button -->
    <div>
      <input type="submit" value="Register" class="form-button" onclick="validateForm(event)">
    </div>
  </form>
</div>

<div class="reservation">
  <label for="chk" aria-hidden="true">Reservation</label>
  <form>
    <!-- First Name Field -->
    <div class="input-container">
      <input type="text" id="firstName" class="form-input" placeholder="Enter First Name">
    </div>

    <!-- Last Name Field -->
    <div class="input-container">
      <input type="text" id="lastName" class="form-input" placeholder="Enter Last Name">
    </div>

    <!-- Phone Number -->
    <div class="input-container">
      <input type="text" id="phoneNumber" class="form-input" placeholder="Enter Phone Number">
    </div>

    <!-- Table Selection -->
    <div class="input-container">
      <select id="tableSelect" class="form-select">
        <option value="">Select Table</option>
        <option value="1">1</option>
        <option value="2">2</option>
      </select>
    </div>

    <!-- Reservation Date and Time -->
    <div class="input-container">
      <input type="datetime-local" id="reservation" name="reservation" class="form-input" placeholder="Select Date and Time">
    </div>

    <!-- Hours Selection -->
    <div class="input-container">
      <select id="hoursSelect" class="form-select">
        <option value="">Select Hours</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
      </select>
    </div>

    <!-- Payment Method -->
    <div class="input-container">
      <select id="paymentMethod" class="form-select">
        <option value="">Select Payment Method</option>
        <option value="Cash">Cash</option>
        <option value="G-Cash">G-Cash</option>
      </select>
    </div>

    <!-- Submit Button -->
    <div>
      <input type="button" value="Register" class="form-button" onclick="submitForm();">
    </div>
  </form>
</div>

</div>

</div>

<div class="calendar-container">
                <div class="calendar-design"></div>
                <div id="calendar"></div>
</div>

</main>

<!-- SweetAlert Function -->
<script>
  function refreshCalendar() {
    $('#calendar').fullCalendar('refetchEvents'); // Reload events from the server
  }


  function submitForm() {
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const tableSelect = document.getElementById('tableSelect').value.trim();
    const reservationDate = document.getElementById('reservation').value.trim();
    const hoursSelect = document.getElementById('hoursSelect').value.trim();
    const paymentMethod = document.getElementById('paymentMethod').value.trim();

    // Check for empty fields
    if (!firstName || !lastName || !phoneNumber || !tableSelect || !reservationDate || !hoursSelect || !paymentMethod) {
      Swal.fire({
        title: 'Error!',
        text: 'Please fill out all fields before submitting.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    // Validate phone number format (Philippines format starting with 09, 11 digits)
    const phoneRegex = /^\b09\d{9}\b/;
    if (!phoneRegex.test(phoneNumber)) {
      Swal.fire({
        icon: 'error',
        title: 'Invalid Phone Number',
        text: 'Please enter a valid phone number (11 digits, starting with 09).',
      });
      return;
    }

    // Check reservation date is in the future
    const now = new Date();
    const reservationDateTime = new Date(reservationDate);
    if (reservationDateTime <= now) {
      Swal.fire({
        title: 'Invalid Reservation Date',
        text: 'Please select a future date and time for your reservation.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    // Send data to the backend via AJAX
    const data = {
      firstName: firstName,
      lastName: lastName,
      phoneNumber: phoneNumber,
      tableSelect: tableSelect,
      reservationDate: reservationDate,
      hoursSelect: hoursSelect,
      paymentMethod: paymentMethod
    };

    fetch('reservation.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
    if (data.status === 'success') {
        Swal.fire({
            title: 'Success!',
            text: 'Your reservation has been submitted successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(() => {
            // Clear form fields
            document.getElementById('firstName').value = '';
            document.getElementById('lastName').value = '';
            document.getElementById('phoneNumber').value = '';
            document.getElementById('tableSelect').value = '';
            document.getElementById('reservation').value = '';
            document.getElementById('hoursSelect').value = '';
            document.getElementById('paymentMethod').value = '';
            refreshCalendar(); // Refresh the calendar
        });
    } else {
        Swal.fire({
            title: 'Error!',
            text: data.message,
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
})

    .catch(error => {
      Swal.fire({
        title: 'Error!',
        text: 'There was an error submitting your reservation.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    });
  }
</script>

<!-- MAIN CONTENT -->


<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>

<script>
function validateForm(event) {
    event.preventDefault(); // Prevent form submission

    var firstName = document.getElementById("first_name").value;
    var lastName = document.getElementById("last_name").value;
    var phoneNumber = document.getElementById("phone_number").value;
    var table = document.getElementById("table").value;
    var hours = document.getElementById("hours").value;
    var paymentMethod = document.getElementById("payment_method").value;

    if (firstName === "" || lastName === "" || phoneNumber === "" || table === "" || hours === "" || paymentMethod === "") {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Please fill out all fields before submitting!',
        });
        return;
    }

    if (!/^\b09\d{9}\b/.test(phoneNumber)) {
        Swal.fire({
            icon: 'error',
            title: 'Invalid Phone Number',
            text: 'Please enter a valid phone number (11 digits, starting with 09)!',
        });
        return;
    }

    fetch('submit_registration.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            first_name: firstName,
            last_name: lastName,
            phone_number: phoneNumber,
            table: table,
            hours: hours,
            payment_method: paymentMethod,
        }),
    })
        .then(response => response.json())
        .then(data => {
    if (data.status === 'error') {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: data.message,
        });
    } else {
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: data.message,
        }).then(() => {
            clearForm(); // Clear the form
            refreshCalendar(); // Refresh the calendar
        });
    }
})

        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'An unexpected error occurred.',
            });
        });
}

// Function to clear form fields
function clearForm() {
    document.getElementById("first_name").value = "";
    document.getElementById("last_name").value = "";
    document.getElementById("phone_number").value = "";
    document.getElementById("table").value = "";
    document.getElementById("hours").value = "";
    document.getElementById("payment_method").value = "";
}

    </script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.7/semantic.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js"></script>

<script>
 $('#calendar').fullCalendar({
    header: {
        left: 'title',
        right: 'month, agendaDay ,prev,next',
    },
    defaultDate: new Date().toISOString().split('T')[0], // Set default date to today
    navLinks: true, // Enable navigation by clicking day/week names
    editable: false, // Disable event moving
    eventLimit: true, // Show "more" link when too many events
    timeZone: 'local', // Use the user's local timezone
    events: function(start, end, timezone, callback) {
        $.ajax({
            url: 'get_events.php', // Fetch events from the server
            dataType: 'json',
            success: function(data) {
                console.log(data); // Log the fetched data for debugging
                var events = data.map(function(event) {
                  
                    return {
                        title: event.title,
                        start:  moment(event.start).format("YYYY-MM-DDTHH:mm"),
                        end:  moment(event.end).format("YYYY-MM-DDTHH:mm"),                  
                        description: event.description,
                        backgroundColor: "#155843"
                    };
                });
                callback(events); // Pass the formatted events to FullCalendar
            },
            error: function(xhr, status, error) {
                console.error("Error fetching events:", status, error);
            }
        });
    },
    eventClick: function(event) {
    const startTime = moment(event.start).format('hh:mm A'); // Format with AM/PM
    const endTime = event.end ? moment(event.end).format('hh:mm A') : 'N/A'; // Check if end time exists

    Swal.fire({
        title: event.title,
        html: `<p>${startTime} - ${endTime}</p> 
               <p>${event.description || 'No description available'}</p>`,
        icon: 'info',
    });
}

});


</script>

</body>

</html>