<?php
// Include the database connection
include('conn.php');
session_start(); // Start the session

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Escape and get username and password from POST data
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Check if the username exists
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Set session variables to indicate the user is logged in
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $username;

            echo json_encode(['success' => 'Login successful']);
        } else {
            echo json_encode(['error' => 'Incorrect password']);
        }
    } else {
        echo json_encode(['error' => 'Username not found']);
    }

    // Close the prepared statement and connection
    $stmt->close();
    $conn->close();
}
?>
