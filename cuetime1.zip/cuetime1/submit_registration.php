<?php
// Include your database connection
require_once 'conn.php'; // Ensure this points to your database connection file

// Set timezone to the desired timezone (adjust this as needed)
date_default_timezone_set('Asia/Manila'); // Set to Philippines timezone or your server's timezone

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from POST request
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $phoneNumber = $_POST['phone_number'];
    $tableNo = $_POST['table'];
    $hours = (int) $_POST['hours']; // Ensure hours is an integer
    $paymentMethod = $_POST['payment_method'];

    // Validate inputs
    if (empty($firstName) || empty($lastName) || empty($phoneNumber) || empty($tableNo) || empty($hours) || empty($paymentMethod)) {
        echo json_encode(['status' => 'error', 'message' => 'All fields are required!']);
        exit;
    }

    if (!preg_match('/^\b09\d{9}\b/', $phoneNumber)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid phone number format.']);
        exit;
    }

    if ($hours <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Hours must be greater than 0.']);
        exit;
    }

    // Calculate start and end time based on hours selected using DateTime
    $startTime = new DateTime(); // Current time
    $endTime = clone $startTime;
    $endTime->add(new DateInterval("PT{$hours}H")); // Add hours to start time

    // Format times to 12-hour format (AM/PM)
    $startTimeFormatted = $startTime->format("Y-m-d g:i A");
    $endTimeFormatted = $endTime->format("Y-m-d g:i A");

    // Get the current date for registration_date
    $registrationDate = new DateTime();
    $registrationDateFormatted = $registrationDate->format("Y-m-d g:i A");

    // Check if the table is already booked during the selected time
    $conn = new mysqli('localhost', 'root', '', 'cue_time'); // Adjust credentials as needed
    if ($conn->connect_error) {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $conn->connect_error]);
        exit;
    }

    // Check for table bookings that overlap with the requested time
    $query = "SELECT * FROM walk_in_registration WHERE table_no = ? AND (
        (start_time < ? AND end_time > ?) OR
        (start_time < ? AND end_time > ?)
    )";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $tableNo, $endTimeFormatted, $startTimeFormatted, $startTimeFormatted, $endTimeFormatted);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Table is already in use.']);
        $result->close();
        $stmt->close();
        $conn->close();
        exit;
    }
    $result->close();

    // Insert data into the database
    $stmt = $conn->prepare("INSERT INTO walk_in_registration (first_name, last_name, phone_number, table_no, hours, payment_method, registration_date, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssisssss", $firstName, $lastName, $phoneNumber, $tableNo, $hours, $paymentMethod, $registrationDateFormatted, $startTimeFormatted, $endTimeFormatted);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Registration submitted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit registration.']);
    }

    $stmt->close();
    $conn->close();
}
?>
