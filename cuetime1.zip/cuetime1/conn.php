<?php
// Database connection settings
$servername = "localhost"; // Change this to your server if needed
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "cue_time"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
