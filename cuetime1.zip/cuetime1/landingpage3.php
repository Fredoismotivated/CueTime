<?php
// Start the session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header('Location: index.php');
    exit();
}
?>

<!-- Landing Page content -->

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Statistics | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">

  <!-- import ng boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- import ng sweetalert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 

  <!-- Sccript ng chart -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
  <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}
/* NAV BAR SA GILID START */
html, body {
    height: 100%; /* Ensure the entire page fits within the viewport */
    overflow: hidden; /* Prevent scrolling */
    background-color: #E5E4E2;
}

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh; /* Make sidebar height fixed */
    width: 78px;
    background: #155843;
    padding: 6px 14px;
    z-index: 1;
    transition: all 0.5s ease;
    overflow: hidden; /* Prevent sidebar from scrolling */
}

.sidebar.open {
    width: 250px;
}

.sidebar .logo-details {
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: relative;
}

.sidebar .logo-details .logo_name {
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    opacity: 0;
    transition: all 0.5s ease;
}

.sidebar.open .logo-details,
.sidebar.open .logo-details .logo_name {
    opacity: 1;
}

.sidebar .logo-details #btn {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    font-size: 22px;
    text-align: center;
    cursor: pointer;
    transition: all 0.5s ease;
}

.sidebar i {
    color: #fff;
    height: 60px;
    min-width: 50px;
    font-size: 28px;
    text-align: center;
    line-height: 60px;
}

.sidebar .nav-list {
    margin-top: 20px;
    height: 100%;
}

.sidebar li {
    position: relative;
    margin: 8px 0;
    list-style: none;
}

.sidebar li i {
    height: 50px;
    line-height: 50px;
    font-size: 18px;
    border-radius: 12px;
}

.sidebar li a {
    display: flex;
    height: 100%;
    width: 100%;
    border-radius: 12px;
    align-items: center;
    text-decoration: none;
    transition: all 0.4s ease;
    background: #11101D;
}

.sidebar li a:hover {
    background: #fff;
}

.sidebar li a .links_name {
    color: #fff;
    font-size: 15px;
    font-weight: 400;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.4s;
}

.sidebar.open li a .links_name {
    opacity: 1;
    pointer-events: auto;
}

.sidebar li a:hover .links_name,
.sidebar li a:hover i {
    transition: all 0.5s ease;
    color: #11101D;
}

.sidebar li.profile {
    position: fixed;
    height: 60px;
    width: 78px;
    left: 0;
    bottom: -8px;
    padding: 10px 14px;
    background: #1d1b31;
    transition: all 0.5s ease;
    overflow: hidden;
}

.sidebar.open li.profile {
    width: 250px;
}

.sidebar li .profile-details {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
}

.sidebar li img {
    height: 45px;
    width: 45px;
    object-fit: contain;
    border-radius: 6px;
    margin-right: 10px;
}

.sidebar li.profile .name,
.sidebar li.profile .job {
    font-size: 15px;
    font-weight: 400;
    color: #fff;
    white-space: nowrap;
}

.sidebar li.profile .job {
    font-size: 12px;
}

.sidebar li.profile #log_out {
    position: absolute;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    background: #1d1b31;
    width: 100%;
    height: 60px;
    line-height: 60px;
    transition: all 0.5s ease;
}


.sidebar.open .profile #log_out {
    width: 30px;
    background: none;
}

.sidebar li.active a {
    background: #fff !important; /* White background */
    color: #11101D !important; /* Text and icon color */
}

.sidebar li.active a .links_name,
.sidebar li.active a i {
    color: #11101D !important; /* Ensure icon and text stay styled */
}


/* Media query for smaller screens (max-width: 768px) */
@media (max-width: 768px) {
    /* Ensure the body and html are confined to the viewport height */
    html, body {
        height: 100%; /* Ensure the entire page fits within the viewport */
        overflow: hidden; /* Prevent scrolling */
    }

    /* Sidebar width adjustment for smaller screens */
    .sidebar {
        width: 20vw; /* Sidebar takes up 20% of the screen width */
        height: 100vh; /* Sidebar height matches the viewport height */
        overflow-y: hidden; /* Prevent scroll in sidebar */
    }

    /* Sidebar logo font size adjustment */
    .sidebar .logo-details .logo_name {
        font-size: calc(1.2vw + 1em); /* Make logo name font smaller */
    }

    /* Sidebar profile name font size adjustment */
    .sidebar li .profile .name {
        font-size: calc(1.5vw + 10px); /* Adjust profile name font size */
    }

    /* Sidebar icon size adjustment */
    .sidebar i {
        font-size: calc(2vw + 2px); /* Make icons smaller */
    }

    /* Styling for bx box-log-out icon */
    .sidebar li.profile #log_out {
        width: auto; /* Allow the button to only take up space for the icon */
        background-color: transparent; /* Match sidebar background */
        border-top: none; /* Remove top border */
        padding: 10px; /* Add padding for consistent spacing */
        display: flex;
        align-items: center;
        justify-content: flex-start; /* Align the logout icon to the left */
    }

    .sidebar li.profile #log_out i.bx.box-log-out {
        font-size: calc(2vw + 1px); /* Keep icon size consistent */
        color: #fff; /* Match icon color with other sidebar items */
        margin-right: 10px; /* Add some space between the icon and any text */
    }

    /* Profile section width adjustment */
    .sidebar li.profile {
        width: 9.2vh; /* padding to sa logout button para pantay lang sa navbar */
    }

    /* Hide images on smaller screens */
    .sidebar li img {
        display: none; /* Hides the image completely */
    }

    /* Hide the "Cue Time" and "By Group:" text */
    .sidebar .profile .name,
    .sidebar .profile .job {
        display: none !important; /* Ensure these elements are hidden */
    }

    /* Home section text font size adjustment */
    .home-section .text {
        font-size: calc(2.5vw + 12px); /* Adjust text size */
    }

    /* Tooltip font size and padding adjustment */
    .sidebar li .tooltip {
        font-size: 12px; /* Adjust tooltip font size */
        padding: 0px 0px; /* Adjust tooltip padding */
    }/* NAV BAR SA GILID END */

}

  </style>

</head>

<body>
<!-- Sidebar Section -->
    <div class="sidebar">
        <div class="logo-details">
            <div class="logo_name">Cue Time 🎱</div>
            <i class='bx bx-menu' id="btn"></i>
        </div>
        <ul class="nav-list">

            <!-- Walk-In Reservation-->
            <li>
                <a href="landingpage.php">
                    <i class='bx bx-user'></i>
                    <span class="links_name">Walk-In</span>
                </a>
            </li> 


            <!-- Analytics Link -->
            <li>
                <a href="landingpage1.php">
                    <i class='bx bxs-bookmark-alt-plus'></i>
                    <span class="links_name">Reservation</span>
                </a>
            </li>

            <!-- Files Link -->
            <li>
                <a href="landingpage2.php">
                    <i class='bx bx-calendar'></i>
                    <span class="links_name">Schedules</span>
                </a>
            </li>

            <!-- Revenue Link -->
            <li class="active"><!--Active tab indicator-->
                <a href="landingpage3.php">
                    <i class='bx bxs-bar-chart-square'></i>
                    <span class="links_name">Analytics</span>
                </a>
            </li>
 
            <!-- Company Section -->
            <li class="profile">
                <div class="profile-details">
                    <img src="assets/Images/1ball.png" alt="profileImg">
                    <div class="name_job">
                        <div class="name">Cue Time</div>
                        <div class="job">By Group: 6</div>
                    </div>
                </div>
                <div id="log_out-container">
                     <i class='bx bx-log-out' id="log_out"></i>
                </div>
            </li>
        </ul>
    </div>
<!-- Sidebar Section -->

<!-- MAIN CONTENT -->
<?php
// Include your database connection file
include('conn.php');

// Check if the connection is successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Function to get total hours from each table (walk-in and reservations)
function getTotalHoursPerMonth($table, $dateColumn) {
    global $conn;
    // Modify the query to use the correct date column and sum hours
    $query = "SELECT MONTH($dateColumn) AS month, SUM(hours) AS total_hours FROM $table GROUP BY MONTH($dateColumn)";
    
    // Run the query
    $result = mysqli_query($conn, $query);
    
    // Check for query errors
    if (!$result) {
        die('Query failed: ' . mysqli_error($conn));
    }

    $months = [];
    $hours = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $months[] = $row['month'];
        $hours[] = $row['total_hours'];
    }

    return ['months' => $months, 'hours' => $hours];
}

// Fetch data for both tables
$walkInData = getTotalHoursPerMonth('walk_in_registration', 'registration_date');
$reservationsData = getTotalHoursPerMonth('reservations', 'reservation_date');

// Function to get total customers by counting the records in both tables
function getTotalCustomers() {
    global $conn;
    
    // Query to get the total number of customers in both tables
    $query_walk_in = "SELECT COUNT(id) AS total_customers FROM walk_in_registration";
    $query_reservations = "SELECT COUNT(id) AS total_customers FROM reservations";
    
    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Calculate total customers by adding counts from both tables
    $totalCustomer = $row_walk_in['total_customers'] + $row_reservations['total_customers'];

    return $totalCustomer;
}

// Assign the total customer count to the variable
$totalCustomer = getTotalCustomers();

// Function to get total revenue by summing hours and multiplying by 100 PHP per hour
function getTotalRevenue() {
    global $conn;

    // Query to sum hours for both tables
    $query_walk_in = "SELECT SUM(hours) AS total_hours FROM walk_in_registration";
    $query_reservations = "SELECT SUM(hours) AS total_hours FROM reservations";
    
    // Execute the queries
    $result_walk_in = mysqli_query($conn, $query_walk_in);
    $result_reservations = mysqli_query($conn, $query_reservations);

    // Check for query errors
    if (!$result_walk_in || !$result_reservations) {
        die('Query failed: ' . mysqli_error($conn));
    }

    // Fetch the results
    $row_walk_in = mysqli_fetch_assoc($result_walk_in);
    $row_reservations = mysqli_fetch_assoc($result_reservations);

    // Calculate total revenue (100 PHP per hour)
    $totalRevenue = ($row_walk_in['total_hours'] + $row_reservations['total_hours']) * 100;

    return $totalRevenue;
}

// Assign the total revenue to the variable
$totalRevenue = getTotalRevenue();
?>

<div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #f7f7f7;">
  <div style="max-width: 500px; width: 100%; background: #fff; margin: 0; box-shadow: 2px 2px 4px rgba(0,0,0,0.125); padding: 30px;">
    <div style="font-size: 24px; font-weight: 700; margin-bottom: 25px; color: #fec107; text-transform: uppercase; text-align: center;">
      Our Analytics
    </div>

    <div>
      <!-- Total Customer Field -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;"> Total customer:</label>
        <input type="text" value="<?php echo isset($totalCustomer) ? $totalCustomer : '0'; ?>" 
               style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <!-- Total Revenue Field -->
      <div style="margin-bottom: 15px; display: flex; align-items: center;">
        <label style="width: 200px; color: #757575; margin-right: 10px; font-size: 14px;">Total revenue:</label>
        <input type="text" value="<?php echo isset($totalRevenue) ? number_format($totalRevenue, 2) : '0.00'; ?>" 
               style="width: 100%; outline: none; border: 1px solid #d5dbd9; font-size: 15px; padding: 8px 10px; border-radius: 3px; transition: all 0.3s ease;">
      </div>

      <canvas id="myChart" style="width:100%;max-width:600px"></canvas>

      <script>
        const months = <?php echo json_encode($walkInData['months']); ?>;
        const walkInHours = <?php echo json_encode($walkInData['hours']); ?>;
        const reservationsHours = <?php echo json_encode($reservationsData['hours']); ?>;

        new Chart("myChart", {
          type: "line",
          data: {
            labels: months,
            datasets: [{
              label: "Walk-in Registration",
              fill: false,
              lineTension: 0,
              backgroundColor: "rgba(255, 99, 132, 0.2)",
              borderColor: "rgba(255, 99, 132, 1)",
              data: walkInHours,
              borderWidth: 2
            }, {
              label: "Reservations",
              fill: false,
              lineTension: 0,
              backgroundColor: "rgba(54, 162, 235, 0.2)",
              borderColor: "rgba(54, 162, 235, 1)",
              data: reservationsHours,
              borderWidth: 2
            }]
          },
          options: {
            responsive: true,
            legend: {display: true},
            scales: {
              yAxes: [{
                ticks: {min: 0, stepSize: 10},
                scaleLabel: {display: true, labelString: "Total Hours"}
              }]
            }
          }
        });
      </script>
    </div>
  </div>
</div>
<!-- MAIN CONTENT -->

<script>
    document.addEventListener("DOMContentLoaded", function() {
        let sidebar = document.querySelector(".sidebar");
        let closeBtn = document.querySelector("#btn");

        // Toggle sidebar visibility on button click
        closeBtn.addEventListener("click", () => {
            sidebar.classList.toggle("open");
        });

        // Logout Confirmation Script
        document.getElementById('log_out').addEventListener('click', function (e) {
    e.preventDefault(); // Prevent default link action
    Swal.fire({
        title: 'Are you sure?',
        text: 'You will be logged out.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, log me out!',
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'logout.php'; // Redirect to logout page
        }
        // Do nothing on cancel, avoiding layout recalculation
    });
});
    });
</script>


</body>

</html>