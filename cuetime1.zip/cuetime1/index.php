<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <title>Login | Cue Time</title>
  <link rel="icon" href="assets/Logo.png" type="image/png" sizes="16x16">
  <link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<style>
/* Global styling */
body {
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  font-family: 'Jost', sans-serif;
  background: linear-gradient(to bottom, #102820, #0c2a29, #081f1f, #061b1b);
}

/* Main container */
.main {
  width: 350px;
  height: 500px;
  overflow: hidden;
  background-color: #e3af12;
  border-radius: 10px;
  box-shadow: 5px 20px 50px #000;
}

/* Hide checkbox used for toggling forms */
#chk {
  display: none;
}

/* Signup and login forms */
.signup, .login {
  position: relative;
  width: 100%;
  height: 100%;
}

label {
  color: #fff;
  font-size: 2.3em;
  justify-content: center;
  display: flex;
  margin: 50px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.5s ease-in-out;
}

/* Input fields */
.input-container {
  width: 60%;
  margin: 20px auto;
  position: relative;
}

input {
  width: 100%;
  height: 10px;
  background: #e0dede;
  padding: 12px;
  border: none;
  outline: none;
  border-radius: 5px;
}

/* Password container for toggle */
.password-container {
  position: relative;
}

.password-toggle {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  cursor: pointer;
  width: 24px; /* Adjust size of the image */
  height: 24px;
}

.password-toggle img {
  width: 100%;
  height: 100%;
  object-fit: contain; /* Ensure image doesn't stretch */
}

/* Buttons */
button {
  width: 60%;
  height: 40px;
  margin: 10px auto;
  justify-content: center;
  display: block;
  color: #fff;
  background: #24231f;
  font-size: 1em;
  font-weight: bold;
  margin-top: 30px;
  outline: none;
  border: none;
  border-radius: 5px;
  transition: 0.2s ease-in;
  cursor: pointer;
}

button:hover {
  background: #4a4841;
}

/* Login form animation */
.login {
  height: 460px;
  background: #eee;
  border-radius: 60% / 10%;
  transform: translateY(-180px);
  transition: 0.8s ease-in-out;
}

.login label {
  color: gray;
  transform: scale(0.6);
}

/* Checkbox toggle behavior */
#chk:checked ~ .login {
  transform: translateY(-500px);
}

#chk:checked ~ .login label {
  transform: scale(1);
}

#chk:checked ~ .signup label {
  transform: scale(0.6);
}

/* Responsive styling for tablets and desktops */
@media (min-width: 768px) {
  .main {
    width: 450px;
  }
}

@media (min-width: 1024px) {
  .main {
    width: 450px;
    height: 540px;
  }
}

</style>   
<body>
  <div class="main">
    <input type="checkbox" id="chk" aria-hidden="true">
    
    <!-- Sign Up Form -->
    <div class="signup">
      <form id="signup-form" onsubmit="return validatePassword(event)">
        <label for="chk" aria-hidden="true">Sign up</label>
        <div class="input-container">
          <input type="text" id="signup-username" name="username" placeholder="Username" required>
        </div>
        <div class="input-container password-container">
          <input type="password" id="signup-password" name="password" placeholder="Password" required>
          <span class="password-toggle" onclick="togglePasswordVisibility('signup-password', this)">
            <img src="assets/Images/hide.png" alt="Show password" id="signup-toggle-icon">
          </span>
        </div>
        <div class="input-container password-container">
          <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm Password" required>
          <span class="password-toggle" onclick="togglePasswordVisibility('confirm-password', this)">
            <img src="assets/Images/hide.png" alt="Show password" id="confirm-toggle-icon">
          </span>
        </div>
        <button type="submit">Sign up</button>
      </form>
    </div>

    <!-- Login Form -->
    <div class="login">
      <form id="login-form">
        <label for="chk" aria-hidden="true">Login</label>
        <div class="input-container">
          <input type="text" id="login-username" name="username" placeholder="Username" required>
        </div>
        <div class="input-container password-container">
          <input type="password" id="login-password" name="password" placeholder="Password" required>
          <span class="password-toggle" onclick="togglePasswordVisibility('login-password', this)">
            <img src="assets/Images/hide.png" alt="Show password" id="login-toggle-icon">
          </span>
        </div>
        <button type="submit">Login</button>
      </form>
    </div>
  </div>

  <style>
  /* para macenter yung ok button ng sweetalert */
  .swal2-popup {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  /* Center the buttons */
  .swal2-popup .swal2-actions {
    display: flex;
    justify-content: center;
    width: 20%;
  }

  /* Ensure the confirm button is properly centered */
  .swal2-popup .swal2-confirm {
    margin: 0;
  }
</style>




  <script>
  // Toggle password visibility
  function togglePasswordVisibility(id, icon) {
    const passwordField = document.getElementById(id);
    const toggleIcon = icon.querySelector('img');
    if (passwordField.type === 'password') {
      passwordField.type = 'text';
      toggleIcon.src = 'assets/Images/show.png';
      toggleIcon.alt = 'Hide password';
    } else {
      passwordField.type = 'password';
      toggleIcon.src = 'assets/Images/hide.png';
      toggleIcon.alt = 'Show password';
    }
  }

  // Clear signup text fields
  function clearSignupFields() {
    document.getElementById('signup-username').value = '';
    document.getElementById('signup-password').value = '';
    document.getElementById('confirm-password').value = '';
  }

  // Validate password match during signup
  function validatePassword(event) {
    event.preventDefault(); // Prevent form submission

    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;

    if (password !== confirmPassword) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Passwords do not match!',
      });
      clearSignupFields(); // Clear fields after failed attempt
      return false; // Prevent form submission
    }

    const form = event.target;
    const formData = new FormData(form);

    fetch('signup.php', {
      method: 'POST',
      body: formData
    }).then(response => response.json())
      .then(data => {
        if (data.success) {
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: data.success,
          }).then(() => {
            clearSignupFields(); // Clear fields after successful sign-up
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: data.error,
          });
          clearSignupFields(); // Clear fields after failed attempt
        }
      }).catch((error) => {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: `An error occurred: ${error.message}`,
        });
        clearSignupFields(); // Clear fields after error
      });
  }

  // Login form submission
  document.getElementById('login-form').onsubmit = function (event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);

    fetch('login.php', {
      method: 'POST',
      body: formData
    }).then(response => response.json())
      .then(data => {
        if (data.success) {
          Swal.fire({
            icon: 'success',
            title: 'Success',
            text: data.success,
          }).then(() => {
            window.location.href = "landingpage.php"; // Redirect immediately after success
          });
        } else {
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: data.error,
          });
          // Clear input fields after failed login attempt
          document.getElementById('login-username').value = ''; // Clear username field
          document.getElementById('login-password').value = ''; // Clear password field
          document.getElementById('login-username').focus(); // Focus on the username field
        }
      }).catch((error) => {
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: `An error occurred: ${error.message}`,
        });
        // Clear input fields after failed login attempt
        document.getElementById('login-username').value = ''; // Clear username field
        document.getElementById('login-password').value = ''; // Clear password field
        document.getElementById('login-username').focus(); // Focus on the username field
      });
  };
</script>

</body>
</html>
