<?php
// Include database connection
include 'conn.php';

try {
    // Query to get events from both tables
    $query = "
        SELECT 
            id, 
            CONCAT(first_name, ' ', last_name) AS title, 
            start_time AS start, 
            end_time AS end, 
            CONCAT(
                'Table ', table_no, ': ', 
                ' (Walk-in Registration)'
            ) AS description
        FROM 
            walk_in_registration
        WHERE 
            start_time IS NOT NULL AND end_time IS NOT NULL
        
        UNION
        
        SELECT 
            id, 
            CONCAT(first_name, ' ', last_name) AS title, 
            start_time AS start, 
            end_time AS end, 
            CONCAT(
                'Table ', table_no, ': ', 
                ' (Reservation)'
            ) AS description
        FROM 
            reservations
        WHERE 
            start_time IS NOT NULL AND end_time IS NOT NULL;
    ";

    // Execute the query
    $result = mysqli_query($conn, $query);

    if (!$result) {
        throw new Exception('Query Failed: ' . mysqli_error($conn));
    }

    // Fetch events
    $events = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $events[] = [
            'id' => $row['id'],
            'title' => $row['title'],
            'start' => $row['start'], // Use raw time from DB
            'end' => $row['end'],     // Use raw time from DB
            'description' => $row['description'],
        ];
    }

    // Return events in JSON format
    header('Content-Type: application/json');
    echo json_encode($events);
} catch (Exception $e) {
    // Handle errors and output JSON with error message
    header('Content-Type: application/json', true, 500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
