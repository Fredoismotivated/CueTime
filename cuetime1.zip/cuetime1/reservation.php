<?php
header('Content-Type: application/json');

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Validate the data
if (
    !isset($data['firstName']) || empty($data['firstName']) ||
    !isset($data['lastName']) || empty($data['lastName']) ||
    !isset($data['phoneNumber']) || empty($data['phoneNumber']) ||
    !isset($data['tableSelect']) || empty($data['tableSelect']) ||
    !isset($data['reservationDate']) || empty($data['reservationDate']) ||
    !isset($data['hoursSelect']) || empty($data['hoursSelect']) ||
    !isset($data['paymentMethod']) || empty($data['paymentMethod'])
) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit();
}

// Database connection (using conn.php file)
require_once 'conn.php';

$firstName = mysqli_real_escape_string($conn, $data['firstName']);
$lastName = mysqli_real_escape_string($conn, $data['lastName']);
$phoneNumber = mysqli_real_escape_string($conn, $data['phoneNumber']);
$tableSelect = mysqli_real_escape_string($conn, $data['tableSelect']);
$reservationDate = mysqli_real_escape_string($conn, $data['reservationDate']);
$hoursSelect = mysqli_real_escape_string($conn, $data['hoursSelect']);
$paymentMethod = mysqli_real_escape_string($conn, $data['paymentMethod']);

// Format the reservation date to include AM/PM
$reservationDateFormatted = date('Y-m-d h:i A', strtotime($reservationDate));

// Calculate the start and end times
$startTime = $reservationDateFormatted; // Start time is the reservation date itself
$endTime = date('Y-m-d h:i A', strtotime($reservationDate . ' + ' . $hoursSelect . ' hours')); // Add hours to calculate end time

// Store the duration in hours (as an integer or appropriate value)
$hoursSelectFormatted = (int)$hoursSelect;  // Assuming the input is in hours (e.g., "2" for 2 hours)

// Check for overlapping reservations for the same table
$checkQuery = "
    SELECT * FROM reservations
    WHERE table_number = '$tableSelect' AND (
        (start_time < '$endTime' AND end_time > '$startTime') OR
        (start_time < '$endTime' AND end_time > '$startTime')
    )
";
$checkResult = mysqli_query($conn, $checkQuery);

// If there is a conflict, determine the exact type of overlap
if (mysqli_num_rows($checkResult) > 0) {
    // Fetch the conflicting reservation
    $conflictingReservation = mysqli_fetch_assoc($checkResult);

    // Check if the conflict is a full overlap
    if (
        (strtotime($startTime) >= strtotime($conflictingReservation['start_time']) && strtotime($startTime) <= strtotime($conflictingReservation['end_time'])) &&
        (strtotime($endTime) >= strtotime($conflictingReservation['start_time']) && strtotime($endTime) <= strtotime($conflictingReservation['end_time']))
    ) {
        echo json_encode(['status' => 'error', 'message' => 'The table is fully reserved during this time.']);
        exit();
    }
    // Check if the reservation starts before an existing one and ends during the same time
    else if (strtotime($startTime) < strtotime($conflictingReservation['start_time']) && strtotime($endTime) > strtotime($conflictingReservation['start_time']) && strtotime($endTime) <= strtotime($conflictingReservation['end_time'])) {
        echo json_encode(['status' => 'error', 'message' => 'The reservation partially overlaps with an existing booking (starts before the existing reservation and ends during it).']);
        exit();
    }
    // Check if the reservation starts during an existing one and ends after it
    else if (strtotime($startTime) >= strtotime($conflictingReservation['start_time']) && strtotime($startTime) < strtotime($conflictingReservation['end_time']) && strtotime($endTime) > strtotime($conflictingReservation['end_time'])) {
        echo json_encode(['status' => 'error', 'message' => 'The reservation partially overlaps with an existing booking (starts during the existing reservation and ends after it).']);
        exit();
    }
    // General fallback for other types of overlap
    else {
        echo json_encode(['status' => 'error', 'message' => 'The table is already reserved during this time.']);
        exit();
    }
}

// Insert reservation into the database if no conflict is found
$query = "INSERT INTO reservations (first_name, last_name, phone_number, table_number, reservation_date, start_time, end_time, hours, payment_method) 
          VALUES ('$firstName', '$lastName', '$phoneNumber', '$tableSelect', '$reservationDateFormatted', '$startTime', '$endTime', '$hoursSelectFormatted', '$paymentMethod')";

$result = mysqli_query($conn, $query);

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'Reservation successful.']);
} else {
    // Output the error message
    echo json_encode(['status' => 'error', 'message' => 'Error inserting reservation into database: ' . mysqli_error($conn)]);
}

mysqli_close($conn);
?>
