<?php
// Include the database connection file
include('conn.php');

// Set the response header to JSON
header('Content-Type: application/json');

// Check if the connection was successful
if ($conn->connect_error) {
    echo json_encode(['error' => 'Connection failed: ' . $conn->connect_error]);
    exit;
}

// Assuming the form data is being passed via POST
$username = $_POST['username'];
$password = $_POST['password'];
$confirmPassword = $_POST['confirm-password'];

// Step 1: Check if the username exists in the "users" table
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['error' => 'Error preparing statement: ' . $conn->error]);
    exit;
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Step 2: If the username exists
if ($result->num_rows > 0) {
    // Step 3: Check if the passwords match
    if ($password === $confirmPassword) {
        // Step 4: Hash the new password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Step 5: Update the password in the database
        $updateSql = "UPDATE users SET password = ? WHERE username = ?";
        $updateStmt = $conn->prepare($updateSql);
        if (!$updateStmt) {
            echo json_encode(['error' => 'Error preparing update statement: ' . $conn->error]);
            exit;
        }

        $updateStmt->bind_param("ss", $hashedPassword, $username);
        if ($updateStmt->execute()) {
            echo json_encode(['success' => 'Password updated successfully.']);
        } else {
            echo json_encode(['error' => 'Error updating password.']);
        }
    } else {
        echo json_encode(['error' => 'Passwords do not match.']);
    }
} else {
    echo json_encode(['error' => 'Username not found.']);
}

// Close the connection
$conn->close();
?>
